import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Subject } from '../../types';
import { SubjectFormModal } from './SubjectFormModal';
import { ConfirmDialog } from '../common/ConfirmDialog';
import {
  BookOpen,
  Plus,
  Search,
  Edit2,
  Trash2,
  CheckCircle2,
  Award,
  FlaskConical,
} from 'lucide-react';

export const SubjectList: React.FC = () => {
  const { subjects, addSubject, updateSubject, deleteSubject } = useApp();

  const [search, setSearch] = useState('');
  const [isAddEditOpen, setIsAddEditOpen] = useState(false);
  const [editingSubject, setEditingSubject] = useState<Subject | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const filteredSubjects = subjects.filter(
    (s) =>
      s.subject_name.toLowerCase().includes(search.toLowerCase()) ||
      s.subject_code.toLowerCase().includes(search.toLowerCase())
  );

  const handleCreateOrUpdate = async (data: Omit<Subject, 'id'>) => {
    // Total max
    const max_marks =
      (data.max_internal ?? 0) +
      (data.max_external ?? 0) +
      (data.has_practical ? data.max_practical ?? 0 : 0);

    const payload = { ...data, max_marks };

    if (editingSubject) {
      return await updateSubject(editingSubject.id, payload);
    } else {
      return await addSubject(payload);
    }
  };

  const handleConfirmDelete = async () => {
    if (deletingId) {
      await deleteSubject(deletingId);
      setDeletingId(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Subject Catalog</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure subjects, maximum internal & external marks, practical components, and pass criteria
          </p>
        </div>

        <button
          onClick={() => {
            setEditingSubject(null);
            setIsAddEditOpen(true);
          }}
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Add Subject</span>
        </button>
      </div>

      {/* Search Input */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm max-w-md">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search subject code or name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-10 pr-3 py-2 text-xs bg-slate-100 border-none rounded-full focus:ring-2 focus:ring-blue-500 focus:outline-none"
          />
        </div>
      </div>

      {/* Subject Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredSubjects.map((subj) => (
          <div
            key={subj.id}
            className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between group hover:border-blue-300 transition-colors"
          >
            <div>
              <div className="flex items-start justify-between gap-2 mb-2">
                <span className="px-2.5 py-1 rounded-md text-[11px] font-mono font-bold bg-blue-50 text-blue-700 border border-blue-100">
                  {subj.subject_code}
                </span>
                <span className="text-[10px] font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded-md">
                  Scope: {subj.class_level || 'All'}
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-600 transition-colors leading-snug">
                {subj.subject_name}
              </h3>

              <div className="mt-4 pt-3 border-t border-slate-100 grid grid-cols-3 gap-2 text-center text-xs">
                <div className="p-2 bg-slate-50 rounded-lg">
                  <span className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Internal</span>
                  <span className="font-bold text-slate-800">{subj.max_internal ?? 20}</span>
                </div>

                <div className="p-2 bg-slate-50 rounded-lg">
                  <span className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider">External</span>
                  <span className="font-bold text-slate-800">{subj.max_external ?? 80}</span>
                </div>

                <div className="p-2 bg-slate-50 rounded-lg">
                  <span className="block text-[10px] font-semibold text-slate-400 uppercase tracking-wider">Practical</span>
                  <span className="font-bold text-slate-800">
                    {subj.has_practical ? subj.max_practical ?? 20 : 'N/A'}
                  </span>
                </div>
              </div>

              <div className="mt-3 flex items-center justify-between text-xs text-slate-600 px-1">
                <div className="flex items-center gap-1">
                  {subj.has_practical ? (
                    <span className="inline-flex items-center gap-1 text-[11px] text-purple-700 font-semibold bg-purple-50 px-2 py-0.5 rounded-md">
                      <FlaskConical className="w-3 h-3" /> Practicals Incl.
                    </span>
                  ) : (
                    <span className="text-[11px] text-slate-400">Theory Only</span>
                  )}
                </div>

                <div className="text-[11px]">
                  Pass Marks:{' '}
                  <span className="font-bold text-emerald-600">{subj.pass_marks}</span> /{' '}
                  <span className="font-bold text-slate-900">{subj.max_marks}</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
              <button
                onClick={() => {
                  setEditingSubject(subj);
                  setIsAddEditOpen(true);
                }}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-1"
              >
                <Edit2 className="w-3.5 h-3.5" />
                <span>Edit</span>
              </button>

              <button
                onClick={() => setDeletingId(subj.id)}
                className="px-3 py-1.5 text-xs font-semibold text-rose-600 bg-rose-50 hover:bg-rose-100 rounded-lg transition-colors flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span>Delete</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Add / Edit Subject Modal */}
      <SubjectFormModal
        isOpen={isAddEditOpen}
        onClose={() => setIsAddEditOpen(false)}
        onSubmit={handleCreateOrUpdate}
        initialData={editingSubject}
      />

      {/* Delete Confirmation */}
      <ConfirmDialog
        isOpen={!!deletingId}
        onClose={() => setDeletingId(null)}
        onConfirm={handleConfirmDelete}
        title="Delete Subject"
        message="Are you sure you want to remove this subject from the curriculum? Associated marks history will also be removed."
      />
    </div>
  );
};
