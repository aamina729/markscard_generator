import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { Subject } from '../../types';
import { BookOpen, Hash, Award } from 'lucide-react';

interface SubjectFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<Subject, 'id'>) => Promise<boolean>;
  initialData?: Subject | null;
}

export const SubjectFormModal: React.FC<SubjectFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData,
}) => {
  const [formData, setFormData] = useState<Omit<Subject, 'id'>>({
    subject_code: '',
    subject_name: '',
    max_marks: 100,
    pass_marks: 40,
    max_internal: 20,
    max_external: 80,
    max_practical: 0,
    has_practical: false,
    class_level: 'All',
  });

  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (initialData) {
      setFormData({
        subject_code: initialData.subject_code,
        subject_name: initialData.subject_name,
        max_marks: initialData.max_marks,
        pass_marks: initialData.pass_marks,
        max_internal: initialData.max_internal ?? 20,
        max_external: initialData.max_external ?? 80,
        max_practical: initialData.max_practical ?? 0,
        has_practical: initialData.has_practical,
        class_level: initialData.class_level || 'All',
      });
    } else {
      setFormData({
        subject_code: 'SUB101',
        subject_name: '',
        max_marks: 100,
        pass_marks: 40,
        max_internal: 20,
        max_external: 80,
        max_practical: 0,
        has_practical: false,
        class_level: 'All',
      });
    }
  }, [initialData, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.subject_name.trim() || !formData.subject_code.trim()) {
      alert('Subject Name and Code are required.');
      return;
    }

    setSaving(true);
    const success = await onSubmit(formData);
    setSaving(false);
    if (success) {
      onClose();
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={initialData ? 'Edit Subject Details' : 'Add New Curriculum Subject'}
      subtitle="Configure subject code, maximum marks breakdown, and pass requirements"
      maxWidth="lg"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Subject Code */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Subject Code *
            </label>
            <div className="relative">
              <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                required
                placeholder="e.g. MAT102"
                value={formData.subject_code}
                onChange={(e) =>
                  setFormData({ ...formData, subject_code: e.target.value.toUpperCase() })
                }
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          {/* Class Level */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Class Scope</label>
            <select
              value={formData.class_level}
              onChange={(e) => setFormData({ ...formData, class_level: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            >
              <option value="All">All Classes</option>
              <option value="Class 9">Class 9 Only</option>
              <option value="Class 10">Class 10 Only</option>
              <option value="Class 11">Class 11 Only</option>
              <option value="Class 12">Class 12 Only</option>
            </select>
          </div>
        </div>

        {/* Subject Name */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            Subject Full Name *
          </label>
          <div className="relative">
            <BookOpen className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              required
              placeholder="e.g. Advanced Mathematics & Analytics"
              value={formData.subject_name}
              onChange={(e) => setFormData({ ...formData, subject_name: e.target.value })}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Practical Toggle */}
        <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-800">Has Practical Exam?</p>
            <p className="text-[10px] text-slate-500">Enable if subject includes laboratory or practical evaluation</p>
          </div>
          <input
            type="checkbox"
            checked={formData.has_practical}
            onChange={(e) => {
              const hasP = e.target.checked;
              setFormData({
                ...formData,
                has_practical: hasP,
                max_practical: hasP ? 20 : 0,
                max_external: hasP ? 60 : 80,
              });
            }}
            className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500 cursor-pointer"
          />
        </div>

        {/* Marks Breakdown Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Max Internal</label>
            <input
              type="number"
              min={0}
              max={100}
              value={formData.max_internal}
              onChange={(e) =>
                setFormData({ ...formData, max_internal: Number(e.target.value) })
              }
              className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Max External</label>
            <input
              type="number"
              min={0}
              max={100}
              value={formData.max_external}
              onChange={(e) =>
                setFormData({ ...formData, max_external: Number(e.target.value) })
              }
              className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Max Practical</label>
            <input
              type="number"
              min={0}
              max={100}
              disabled={!formData.has_practical}
              value={formData.has_practical ? formData.max_practical : 0}
              onChange={(e) =>
                setFormData({ ...formData, max_practical: Number(e.target.value) })
              }
              className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg disabled:bg-slate-50 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          <div>
            <label className="block text-[11px] font-semibold text-slate-600 mb-1">Passing Marks</label>
            <input
              type="number"
              min={0}
              max={100}
              value={formData.pass_marks}
              onChange={(e) =>
                setFormData({ ...formData, pass_marks: Number(e.target.value) })
              }
              className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg font-bold text-blue-600 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="p-3 bg-blue-50/60 border border-blue-200/60 rounded-xl text-xs text-blue-900 flex items-center justify-between font-semibold">
          <span>Calculated Subject Max Marks:</span>
          <span className="text-sm font-black text-blue-700">
            {(formData.max_internal ?? 0) +
              (formData.max_external ?? 0) +
              (formData.has_practical ? formData.max_practical ?? 0 : 0)}{' '}
            Marks
          </span>
        </div>

        {/* Submit Actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl hover:bg-slate-50 transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition disabled:opacity-50"
          >
            {saving ? 'Saving...' : initialData ? 'Update Subject' : 'Add Subject'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
