import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { SchoolSettings } from '../../types';
import {
  Building2,
  Save,
  Palette,
  Shield,
  Phone,
  Mail,
  Globe,
  MapPin,
  Sparkles,
  RotateCcw,
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { settings, updateSettings, resetDatabase, showToast } = useApp();

  const [formData, setFormData] = useState<SchoolSettings>({
    school_name: '',
    school_code: '',
    affiliation_no: '',
    address: '',
    city_state_zip: '',
    phone: '',
    email: '',
    website: '',
    logo_url: '',
    seal_url: '',
    principal_name: '',
    principal_title: '',
    class_teacher_name: '',
    academic_year_current: '',
    card_theme: 'classic',
  });

  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (settings) {
      setFormData({ ...settings });
    }
  }, [settings]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    const success = await updateSettings(formData);
    setSaving(false);
  };

  const handleResetData = async () => {
    if (window.confirm('Reset database back to initial sample records?')) {
      await resetDatabase();
    }
  };

  return (
    <div className="space-y-6 max-w-4xl">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">School Settings & Profile</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Configure school profile headers, affiliation numbers, logo, seal, and default marks card styling
          </p>
        </div>

        <button
          onClick={handleResetData}
          className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition flex items-center gap-1.5 cursor-pointer self-start sm:self-auto"
        >
          <RotateCcw className="w-3.5 h-3.5 text-slate-500" />
          <span>Reset Sample Records</span>
        </button>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* School Identity Section */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3">
            <Building2 className="w-4 h-4 text-blue-600" />
            <span>School Identity & Registration</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Official School Name
              </label>
              <input
                type="text"
                required
                value={formData.school_name}
                onChange={(e) => setFormData({ ...formData, school_name: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">School Code</label>
              <input
                type="text"
                value={formData.school_code}
                onChange={(e) => setFormData({ ...formData, school_code: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Board Affiliation Number
              </label>
              <input
                type="text"
                value={formData.affiliation_no}
                onChange={(e) => setFormData({ ...formData, affiliation_no: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Current Academic Session Year
              </label>
              <input
                type="text"
                value={formData.academic_year_current}
                onChange={(e) =>
                  setFormData({ ...formData, academic_year_current: e.target.value })
                }
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg font-bold text-blue-700 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Default Card Theme
              </label>
              <select
                value={formData.card_theme}
                onChange={(e) =>
                  setFormData({ ...formData, card_theme: e.target.value as any })
                }
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg font-semibold focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                <option value="classic">Classic Traditional</option>
                <option value="modern">Modern Minimal</option>
                <option value="academic">Academic Blue</option>
              </select>
            </div>
          </div>
        </div>

        {/* Contact & Location Section */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3">
            <MapPin className="w-4 h-4 text-emerald-600" />
            <span>Address & Contact Coordinates</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Street Address</label>
              <input
                type="text"
                value={formData.address}
                onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">City, State & Zip</label>
              <input
                type="text"
                value={formData.city_state_zip}
                onChange={(e) => setFormData({ ...formData, city_state_zip: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Phone Number</label>
              <input
                type="text"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Email Address</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Branding & Signatures Section */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 shadow-sm space-y-4">
          <h2 className="text-sm font-bold text-slate-900 flex items-center gap-2 border-b border-slate-100 pb-3">
            <Shield className="w-4 h-4 text-purple-600" />
            <span>Logo, Official Seal & Authorities</span>
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">School Logo URL</label>
              <input
                type="text"
                value={formData.logo_url}
                onChange={(e) => setFormData({ ...formData, logo_url: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Official Seal URL</label>
              <input
                type="text"
                value={formData.seal_url}
                onChange={(e) => setFormData({ ...formData, seal_url: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Principal Name</label>
              <input
                type="text"
                value={formData.principal_name}
                onChange={(e) => setFormData({ ...formData, principal_name: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg font-semibold focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Principal Title</label>
              <input
                type="text"
                value={formData.principal_title}
                onChange={(e) => setFormData({ ...formData, principal_title: e.target.value })}
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Save Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition flex items-center gap-2 disabled:opacity-50 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{saving ? 'Saving...' : 'Save Settings'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
