import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { GraduationCap, Lock, User, Key, ShieldCheck, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

export const LoginModal: React.FC = () => {
  const { login } = useAuth();
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('admin123');
  const [role, setRole] = useState('Admin');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const success = await login(username, role);
    setLoading(false);
    if (!success) {
      setError('Invalid credentials. Please try again.');
    }
  };

  const handleQuickLogin = async (userRole: 'Admin' | 'Teacher' | 'Principal') => {
    const uname = userRole.toLowerCase();
    setUsername(uname);
    setRole(userRole);
    setLoading(true);
    await login(uname, userRole);
    setLoading(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/80 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 10 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        className="w-full max-w-md bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden"
      >
        {/* Top Banner */}
        <div className="bg-slate-900 text-white p-6 text-center relative overflow-hidden">
          <div className="w-12 h-12 mx-auto rounded-xl bg-white/10 backdrop-blur-md flex items-center justify-center text-white border border-white/20 shadow-md mb-3">
            <GraduationCap className="w-6 h-6 text-amber-300" />
          </div>

          <h2 className="text-lg font-bold tracking-tight">Academic ERP System</h2>
          <p className="text-xs text-slate-300 mt-1">Student Marks Card & Records Management</p>
        </div>

        {/* Form Body */}
        <div className="p-6 space-y-4">
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg font-medium">
                {error}
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Username</label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="text"
                  required
                  placeholder="Enter username (e.g. admin)"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-100 border-none rounded-lg font-semibold text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Password</label>
              <div className="relative">
                <Key className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
                <input
                  type="password"
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-slate-100 border-none rounded-lg font-semibold text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Access Role</label>
              <select
                value={role}
                onChange={(e) => setRole(e.target.value)}
                className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg font-bold text-slate-800 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              >
                <option value="Admin">Administrator (Full Access)</option>
                <option value="Teacher">Class Teacher (Marks Entry)</option>
                <option value="Principal">Principal (Approval & Reports)</option>
              </select>
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors disabled:opacity-50 cursor-pointer"
            >
              {loading ? 'Authenticating...' : 'Sign In to Portal'}
            </button>
          </form>

          {/* Quick Demo Login Preset Buttons */}
          <div className="pt-3 border-t border-slate-100">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider text-center mb-2 flex items-center justify-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-500" /> Quick Demo Sign In Presets
            </p>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => handleQuickLogin('Admin')}
                className="p-2 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 text-slate-800 border border-slate-200/80 rounded-lg text-[10px] font-bold transition-colors"
              >
                Admin
              </button>
              <button
                type="button"
                onClick={() => handleQuickLogin('Teacher')}
                className="p-2 bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-200/80 rounded-lg text-[10px] font-bold transition-colors"
              >
                Teacher
              </button>
              <button
                type="button"
                onClick={() => handleQuickLogin('Principal')}
                className="p-2 bg-slate-100 hover:bg-purple-50 hover:text-purple-700 text-slate-800 border border-slate-200/80 rounded-lg text-[10px] font-bold transition-colors"
              >
                Principal
              </button>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};
