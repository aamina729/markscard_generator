import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import {
  BarChart3,
  TrendingUp,
  Award,
  Users,
  Download,
  AlertTriangle,
  CheckCircle2,
  PieChart as PieIcon,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

export const AnalyticsView: React.FC = () => {
  const { stats, students, subjects, marks } = useApp();
  const [selectedClass, setSelectedClass] = useState('All');

  if (!stats) return null;

  // Filtered remedial list (students with any failed subject or below 50%)
  const remedialStudents = students.filter((st) => {
    const stMarks = marks.filter((m) => m.student_id === st.id);
    const failed = stMarks.some((m) => m.pass_status === 'Fail');
    return failed;
  });

  // Export full result gazette CSV
  const handleExportGazette = () => {
    const headers = [
      'Student ID',
      'Roll No',
      'Name',
      'Class',
      'Section',
      'Total Marks Obtained',
      'Overall %',
      'Grade',
      'Result Status',
    ];

    const rows = students.map((st) => {
      const stMarks = marks.filter((m) => m.student_id === st.id);
      const totalObtained = stMarks.reduce((a, b) => a + b.total_obtained, 0);
      const stSubjects = subjects.filter(
        (sb) => sb.class_level === 'All' || sb.class_level === st.class
      );
      const maxTotal = stSubjects.reduce((a, b) => a + b.max_marks, 0);
      const pct = maxTotal > 0 ? Math.round((totalObtained / maxTotal) * 100) : 0;
      const hasFailed = stMarks.some((m) => m.pass_status === 'Fail');

      return [
        st.student_id,
        st.roll_number,
        `"${st.name}"`,
        st.class,
        st.section,
        totalObtained,
        `${pct}%`,
        pct >= 90 ? 'A+' : pct >= 80 ? 'A' : pct >= 70 ? 'B+' : pct >= 60 ? 'B' : pct >= 50 ? 'C' : 'D',
        hasFailed ? 'FAIL' : 'PASS',
      ];
    });

    const csvContent =
      'data:text/csv;charset=utf-8,' +
      [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Academic_Result_Gazette_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Academic Analytics</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Institutional performance reporting, pass rate benchmarks, and result gazette export
          </p>
        </div>

        <button
          onClick={handleExportGazette}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-2 cursor-pointer self-start sm:self-auto"
        >
          <Download className="w-4 h-4" />
          <span>Export Result Gazette (CSV)</span>
        </button>
      </div>

      {/* Analytics Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Institutional Pass Rate</p>
            <p className="text-3xl font-black text-emerald-600 mt-1">{stats.passPercentage}%</p>
            <p className="text-[11px] text-slate-500 mt-0.5">Across all enrolled classes</p>
          </div>
          <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
            <CheckCircle2 className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Mean Percentage Score</p>
            <p className="text-3xl font-black text-blue-600 mt-1">{stats.averagePercentage}%</p>
            <p className="text-[11px] text-slate-500 mt-0.5">Average student score</p>
          </div>
          <div className="p-3 bg-blue-50 text-blue-600 rounded-xl">
            <TrendingUp className="w-6 h-6" />
          </div>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <p className="text-xs font-bold text-slate-400 uppercase">Remedial Attention List</p>
            <p className="text-3xl font-black text-rose-600 mt-1">{remedialStudents.length}</p>
            <p className="text-[11px] text-slate-500 mt-0.5">Students needing coaching</p>
          </div>
          <div className="p-3 bg-rose-50 text-rose-600 rounded-xl">
            <AlertTriangle className="w-6 h-6" />
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Class Pass Rate Bar Chart */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 mb-1">Class-Wise Pass Rates</h3>
          <p className="text-xs text-slate-500 mb-4">Percentage of passing students per class group</p>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.classWisePassRate}>
                <XAxis dataKey="class_name" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: 'none',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="pass_pct" fill="#10b981" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Grade Distribution */}
        <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs">
          <h3 className="text-sm font-bold text-slate-900 mb-1">Grade Level Breakdown</h3>
          <p className="text-xs text-slate-500 mb-4">Distribution of total grades awarded</p>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.gradeDistribution}>
                <XAxis dataKey="grade" stroke="#64748b" fontSize={12} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: 'none',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="count" fill="#3b82f6" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Remedial List Table */}
      {remedialStudents.length > 0 && (
        <div className="bg-white p-5 rounded-2xl border border-rose-200/80 shadow-xs">
          <div className="flex items-center justify-between mb-3">
            <div>
              <h3 className="text-sm font-bold text-rose-950 flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-rose-600" />
                <span>Remedial Attention Students</span>
              </h3>
              <p className="text-xs text-slate-500">
                Students with failed subjects or requiring academic improvement
              </p>
            </div>
            <span className="text-xs font-bold bg-rose-100 text-rose-800 px-2.5 py-1 rounded-md">
              {remedialStudents.length} Students
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-rose-50/60 text-rose-950 font-bold border-b border-rose-100">
                  <th className="p-3">Student</th>
                  <th className="p-3">ID & Roll</th>
                  <th className="p-3">Class</th>
                  <th className="p-3">Parent Contact</th>
                  <th className="p-3">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {remedialStudents.map((st) => (
                  <tr key={st.id}>
                    <td className="p-3 font-bold text-slate-900">{st.name}</td>
                    <td className="p-3 font-mono text-slate-600">
                      {st.student_id} (Roll: {st.roll_number})
                    </td>
                    <td className="p-3 text-slate-700 font-semibold">
                      {st.class} - {st.section}
                    </td>
                    <td className="p-3 text-slate-700">
                      {st.parent_name} ({st.phone})
                    </td>
                    <td className="p-3">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-100 text-rose-800">
                        Needs Support
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
