import React from 'react';
import { useApp } from '../../context/AppContext';
import { ActiveTab } from '../common/Sidebar';
import {
  Users,
  Building2,
  BookOpen,
  Award,
  TrendingUp,
  FileCheck2,
  Edit3,
  UserPlus,
  ArrowUpRight,
  CheckCircle2,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { motion } from 'motion/react';

interface DashboardProps {
  onNavigate: (tab: ActiveTab) => void;
  onSelectStudentCard: (studentId: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate, onSelectStudentCard }) => {
  const { stats, students, loading } = useApp();

  if (loading || !stats) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-xs font-semibold text-slate-500">Loading Academic Metrics...</p>
        </div>
      </div>
    );
  }

  const statCards = [
    {
      title: 'Total Students',
      value: stats.totalStudents,
      subtitle: 'Enrolled across all grades',
      icon: <Users className="w-5 h-5 text-blue-600" />,
      delta: '+12% this term',
    },
    {
      title: 'Active Classes',
      value: stats.totalClasses,
      subtitle: 'Grade & Section groups',
      icon: <Building2 className="w-5 h-5 text-indigo-600" />,
      delta: 'Active Sections',
    },
    {
      title: 'Curriculum Subjects',
      value: stats.totalSubjects,
      subtitle: 'Evaluation catalog',
      icon: <BookOpen className="w-5 h-5 text-purple-600" />,
      delta: 'Core Catalog',
    },
    {
      title: 'Pass Percentage',
      value: `${stats.passPercentage}%`,
      subtitle: `Class Avg: ${stats.averagePercentage}%`,
      icon: <Award className="w-5 h-5 text-emerald-600" />,
      delta: 'Target 95%',
    },
  ];

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-slate-900 text-white rounded-xl p-6 shadow-md border border-slate-800 relative overflow-hidden flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="relative z-10">
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider bg-blue-600/30 text-blue-300 border border-blue-500/30 mb-2">
            <Sparkles className="w-3.5 h-3.5 text-amber-300" /> Academic ERP Portal
          </span>
          <h1 className="text-2xl font-bold tracking-tight text-white">Student Marks & Result Center</h1>
          <p className="text-xs text-slate-400 mt-1 max-w-xl">
            Automated marks record management, real-time CGPA/Grade computation, and official printable PDF marks card generation.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 relative z-10">
          <button
            onClick={() => onNavigate('marks-entry')}
            className="bg-blue-600 hover:bg-blue-700 text-white font-medium text-xs sm:text-sm px-4 py-2.5 rounded-lg shadow-sm transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Edit3 className="w-4 h-4" /> Enter Marks
          </button>
          <button
            onClick={() => onNavigate('marks-card')}
            className="bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-xs sm:text-sm px-4 py-2.5 rounded-lg border border-slate-700 transition-colors flex items-center gap-2 cursor-pointer"
          >
            <FileCheck2 className="w-4 h-4 text-blue-400" /> Marks Cards
          </button>
        </div>
      </div>

      {/* Metric Cards Grid - Matching Design HTML */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {statCards.map((card, idx) => (
          <motion.div
            key={card.title}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: idx * 0.05 }}
            className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col justify-between"
          >
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">
                  {card.title}
                </p>
                <p className="text-2xl font-bold text-slate-900">{card.value}</p>
              </div>
              <div className="p-2 bg-slate-50 rounded-lg border border-slate-100">
                {card.icon}
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-500 font-medium">{card.subtitle}</span>
              <span className="text-emerald-600 font-semibold text-[11px]">{card.delta}</span>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Quick Navigation Cards */}
      <div>
        <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3">
          Quick Actions
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <button
            onClick={() => onNavigate('students')}
            className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:border-blue-400 hover:shadow-md transition text-left group cursor-pointer"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="p-2 bg-blue-50 text-blue-600 rounded-lg group-hover:bg-blue-600 group-hover:text-white transition-colors">
                <UserPlus className="w-5 h-5" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-blue-600 transition" />
            </div>
            <p className="text-sm font-bold text-slate-900">Manage Students</p>
            <p className="text-xs text-slate-500 mt-0.5">Register, update, or search student profiles</p>
          </button>

          <button
            onClick={() => onNavigate('marks-entry')}
            className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:border-emerald-400 hover:shadow-md transition text-left group cursor-pointer"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="p-2 bg-emerald-50 text-emerald-600 rounded-lg group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                <Edit3 className="w-5 h-5" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-600 transition" />
            </div>
            <p className="text-sm font-bold text-slate-900">Batch Marks Entry</p>
            <p className="text-xs text-slate-500 mt-0.5">Enter internal, external, and practical scores</p>
          </button>

          <button
            onClick={() => onNavigate('marks-card')}
            className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm hover:border-purple-400 hover:shadow-md transition text-left group cursor-pointer"
          >
            <div className="flex items-center justify-between mb-2">
              <div className="p-2 bg-purple-50 text-purple-600 rounded-lg group-hover:bg-purple-600 group-hover:text-white transition-colors">
                <FileCheck2 className="w-5 h-5" />
              </div>
              <ArrowUpRight className="w-4 h-4 text-slate-400 group-hover:text-purple-600 transition" />
            </div>
            <p className="text-sm font-bold text-slate-900">Print Marks Cards</p>
            <p className="text-xs text-slate-500 mt-0.5">Generate high-DPI official PDF marksheets</p>
          </button>
        </div>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Grade Distribution */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Grade Breakdown</h3>
              <p className="text-xs text-slate-500">Distribution of subject grades (A+ to F)</p>
            </div>
            <span className="text-[10px] font-bold text-blue-600 bg-blue-50 px-2.5 py-1 rounded-md uppercase tracking-wider">
              Live Evaluation
            </span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.gradeDistribution}>
                <XAxis dataKey="grade" stroke="#64748b" fontSize={12} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: 'none',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="count" fill="#2563eb" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Subject Averages */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Subject Performance</h3>
              <p className="text-xs text-slate-500">Average obtained score per subject</p>
            </div>
            <span className="text-[10px] font-bold text-purple-600 bg-purple-50 px-2.5 py-1 rounded-md uppercase tracking-wider">
              Out of 100
            </span>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={stats.subjectAverages}>
                <XAxis dataKey="subject_name" stroke="#64748b" fontSize={11} tickLine={false} />
                <YAxis stroke="#64748b" fontSize={12} tickLine={false} domain={[0, 100]} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    border: 'none',
                    borderRadius: '8px',
                    color: '#fff',
                    fontSize: '12px',
                  }}
                />
                <Bar dataKey="avg_score" fill="#7c3aed" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Recent Marks Entry Table & Top Rankers */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recent Entries - Matching Design HTML Table */}
        <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden flex flex-col">
          <div className="p-5 border-b border-slate-100 flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Recent Marks Activity</h3>
              <p className="text-xs text-slate-500">Latest mark evaluations entered</p>
            </div>
            <button
              onClick={() => onNavigate('marks-entry')}
              className="text-xs font-semibold text-blue-600 hover:text-blue-800"
            >
              View All &rarr;
            </button>
          </div>

          <div className="overflow-x-auto flex-1">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-100 text-[10px] text-slate-500 uppercase font-bold tracking-widest h-10">
                  <th className="py-2.5 px-4">Student</th>
                  <th className="py-2.5 px-4">Class</th>
                  <th className="py-2.5 px-4">Subject</th>
                  <th className="py-2.5 px-4">Obtained</th>
                  <th className="py-2.5 px-4">Grade</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {stats.recentMarksEntries.map((entry, idx) => (
                  <tr key={idx} className="h-12 border-b border-slate-50 hover:bg-slate-50 transition-colors">
                    <td className="py-2 px-4 font-semibold text-slate-900">
                      {entry.student_name}
                      <span className="block text-[10px] font-mono text-slate-400">
                        {entry.student_id}
                      </span>
                    </td>
                    <td className="py-2 px-4 text-slate-600">{entry.class_section}</td>
                    <td className="py-2 px-4 text-slate-700 font-medium">{entry.subject_name}</td>
                    <td className="py-2 px-4 font-bold text-slate-900">{entry.marks_obtained}</td>
                    <td className="py-2 px-4">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-md font-bold text-[10px] ${
                          entry.grade === 'A+' || entry.grade === 'A'
                            ? 'bg-emerald-100 text-emerald-700'
                            : entry.grade === 'F'
                            ? 'bg-amber-100 text-amber-700'
                            : 'bg-blue-100 text-blue-700'
                        }`}
                      >
                        {entry.grade}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Top Performing Students */}
        <div className="bg-white p-5 rounded-xl border border-slate-200 shadow-sm flex flex-col">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-bold text-slate-900">Top Performers</h3>
              <p className="text-xs text-slate-500">Class academic leaders</p>
            </div>
            <Award className="w-5 h-5 text-amber-500" />
          </div>

          <div className="space-y-2.5 flex-1">
            {students.slice(0, 4).map((student, rank) => (
              <div
                key={student.id}
                onClick={() => onSelectStudentCard(student.id)}
                className="flex items-center justify-between p-2.5 rounded-lg border border-slate-100 hover:border-blue-200 hover:bg-slate-50 cursor-pointer transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-6 h-6 rounded-md flex items-center justify-center font-bold text-xs ${
                      rank === 0
                        ? 'bg-amber-400 text-amber-950'
                        : rank === 1
                        ? 'bg-slate-300 text-slate-800'
                        : rank === 2
                        ? 'bg-amber-600 text-white'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {rank + 1}
                  </div>
                  <img
                    src={
                      student.photo ||
                      'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'
                    }
                    alt={student.name}
                    className="w-8 h-8 rounded-full object-cover border border-slate-200"
                  />
                  <div>
                    <p className="text-xs font-bold text-slate-900">{student.name}</p>
                    <p className="text-[10px] text-slate-500 font-mono">
                      {student.class}-{student.section} | ID: {student.student_id}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-semibold text-blue-600 hover:text-blue-800">
                  Card &rarr;
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
