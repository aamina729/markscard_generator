import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { calculateGrade, validateMarksInput } from '../../utils/academicUtils';
import {
  Edit3,
  Save,
  CheckCircle2,
  AlertCircle,
  Filter,
  Sparkles,
  BookOpen,
  Users,
  Check,
} from 'lucide-react';

export const MarksEntry: React.FC = () => {
  const { students, subjects, marks, saveBatchMarks, showToast } = useApp();

  const [selectedClass, setSelectedClass] = useState('Class 10');
  const [selectedSection, setSelectedSection] = useState('A');
  const [selectedSubjectId, setSelectedSubjectId] = useState(subjects[0]?.id || '');

  // Local grid state for batch editing
  const [gridEntries, setGridEntries] = useState<
    Record<
      string,
      {
        internal: number;
        external: number;
        practical: number;
        remarks: string;
        attendance: number;
        error?: string;
      }
    >
  >({});

  const [saving, setSaving] = useState(false);

  // Filter students for active class & section
  const classStudents = students.filter(
    (s) => s.class === selectedClass && s.section === selectedSection
  );

  const currentSubject = subjects.find((s) => s.id === selectedSubjectId) || subjects[0];

  // Initialize grid when class/section/subject changes
  useEffect(() => {
    if (!currentSubject) return;

    const initialMap: typeof gridEntries = {};
    classStudents.forEach((st) => {
      const existingMark = marks.find(
        (m) => m.student_id === st.id && m.subject_id === currentSubject.id
      );

      initialMap[st.id] = {
        internal: existingMark ? existingMark.internal_marks : 15,
        external: existingMark ? existingMark.external_marks : 50,
        practical: existingMark ? existingMark.practical_marks : currentSubject.has_practical ? 15 : 0,
        remarks: existingMark ? existingMark.remarks : '',
        attendance: existingMark ? existingMark.attendance_pct ?? 92 : 92,
      };
    });

    setGridEntries(initialMap);
  }, [selectedClass, selectedSection, selectedSubjectId, students, marks]);

  const handleInputChange = (
    studentId: string,
    field: 'internal' | 'external' | 'practical' | 'attendance' | 'remarks',
    value: any
  ) => {
    if (!currentSubject) return;

    setGridEntries((prev) => {
      const current = prev[studentId] || {
        internal: 0,
        external: 0,
        practical: 0,
        remarks: '',
        attendance: 90,
      };

      const updated = { ...current, [field]: value };

      // Validation
      const internalNum = Number(updated.internal) || 0;
      const externalNum = Number(updated.external) || 0;
      const practicalNum = Number(updated.practical) || 0;

      const validation = validateMarksInput(
        currentSubject,
        internalNum,
        externalNum,
        practicalNum
      );

      updated.error = validation.isValid ? undefined : validation.error;

      return { ...prev, [studentId]: updated };
    });
  };

  const handleSaveAll = async () => {
    if (!currentSubject) return;

    // Check for validation errors
    const hasErrors = Object.values(gridEntries).some((e: any) => !!e.error);
    if (hasErrors) {
      showToast('Validation Error', 'Please fix highlighted errors before saving', 'error');
      return;
    }

    const payload = classStudents.map((st) => {
      const entry = gridEntries[st.id] || {
        internal: 0,
        external: 0,
        practical: 0,
        remarks: '',
        attendance: 90,
      };

      return {
        student_id: st.id,
        subject_id: currentSubject.id,
        internal_marks: Number(entry.internal) || 0,
        external_marks: Number(entry.external) || 0,
        practical_marks: currentSubject.has_practical ? Number(entry.practical) || 0 : 0,
        remarks: entry.remarks,
        attendance_pct: Number(entry.attendance) || 90,
      };
    });

    setSaving(true);
    const success = await saveBatchMarks(payload);
    setSaving(false);
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">Batch Marks Entry</h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Select Class, Section, and Subject to evaluate and update student marks in real-time
          </p>
        </div>

        <button
          onClick={handleSaveAll}
          disabled={saving || classStudents.length === 0}
          className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-md transition flex items-center gap-2 disabled:opacity-50 cursor-pointer self-start sm:self-auto"
        >
          <Save className="w-4 h-4" />
          <span>{saving ? 'Saving...' : 'Save Marks Batch'}</span>
        </button>
      </div>

      {/* Class & Subject Selector Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4">
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Class</label>
            <select
              value={selectedClass}
              onChange={(e) => setSelectedClass(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="Class 9">Class 9</option>
              <option value="Class 10">Class 10</option>
              <option value="Class 11">Class 11</option>
              <option value="Class 12">Class 12</option>
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">Section</label>
            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="A">Section A</option>
              <option value="B">Section B</option>
              <option value="C">Section C</option>
            </select>
          </div>

          <div className="min-w-[200px]">
            <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
              Evaluation Subject
            </label>
            <select
              value={selectedSubjectId}
              onChange={(e) => setSelectedSubjectId(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-bold text-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {subjects.map((sub) => (
                <option key={sub.id} value={sub.id}>
                  {sub.subject_code} - {sub.subject_name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Subject Limits Info */}
        {currentSubject && (
          <div className="flex items-center gap-3 text-xs bg-slate-50 border border-slate-200 px-4 py-2 rounded-lg text-slate-800 font-medium">
            <BookOpen className="w-4 h-4 text-blue-600 shrink-0" />
            <div>
              <span className="font-bold">{currentSubject.subject_name}</span> | Max Int:{' '}
              <span className="font-bold">{currentSubject.max_internal ?? 20}</span>, Ext:{' '}
              <span className="font-bold">{currentSubject.max_external ?? 80}</span>
              {currentSubject.has_practical && (
                <span className="ml-1">
                  , Prac: <span className="font-bold">{currentSubject.max_practical ?? 20}</span>
                </span>
              )}
              , Total: <span className="font-bold text-blue-700">{currentSubject.max_marks}</span>
            </div>
          </div>
        )}
      </div>

      {/* Marks Matrix Grid */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-100 text-[10px] text-slate-500 uppercase font-bold tracking-widest h-10">
                <th className="py-2.5 px-4">Student Details</th>
                <th className="py-2.5 px-3 w-24">Internal ({currentSubject?.max_internal ?? 20})</th>
                <th className="py-2.5 px-3 w-24">External ({currentSubject?.max_external ?? 80})</th>
                {currentSubject?.has_practical && (
                  <th className="py-2.5 px-3 w-24">Practical ({currentSubject?.max_practical ?? 20})</th>
                )}
                <th className="py-2.5 px-3 w-24">Total</th>
                <th className="py-2.5 px-3 w-20">Percentage</th>
                <th className="py-2.5 px-3 w-20">Grade</th>
                <th className="py-2.5 px-3 w-20">Status</th>
                <th className="py-2.5 px-4">Remarks / Feedback</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {classStudents.length === 0 ? (
                <tr>
                  <td colSpan={9} className="p-8 text-center text-slate-500">
                    No students registered in {selectedClass}-{selectedSection}.
                  </td>
                </tr>
              ) : (
                classStudents.map((student) => {
                  const entry = gridEntries[student.id] || {
                    internal: 0,
                    external: 0,
                    practical: 0,
                    remarks: '',
                    attendance: 90,
                  };

                  const internalNum = Number(entry.internal) || 0;
                  const externalNum = Number(entry.external) || 0;
                  const practicalNum = currentSubject?.has_practical
                    ? Number(entry.practical) || 0
                    : 0;

                  const totalObtained = internalNum + externalNum + practicalNum;
                  const maxTotal = currentSubject?.max_marks || 100;
                  const pct = Math.round((totalObtained / maxTotal) * 100 * 10) / 10;
                  const { grade } = calculateGrade(pct);
                  const isPass = totalObtained >= (currentSubject?.pass_marks || 40);

                  return (
                    <tr
                      key={student.id}
                      className={`h-14 border-b border-slate-50 hover:bg-slate-50 transition-colors ${
                        entry.error ? 'bg-rose-50/50' : ''
                      }`}
                    >
                      {/* Student Info */}
                      <td className="py-2 px-4">
                        <div className="flex items-center gap-2.5">
                          <img
                            src={
                              student.photo ||
                              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'
                            }
                            alt={student.name}
                            className="w-8 h-8 rounded-full object-cover border border-slate-200"
                          />
                          <div>
                            <div className="font-bold text-slate-900">{student.name}</div>
                            <div className="text-[10px] text-slate-400 font-mono">
                              Roll: {student.roll_number} | ID: {student.student_id}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Internal Input */}
                      <td className="py-2 px-3">
                        <input
                          type="number"
                          min={0}
                          max={currentSubject?.max_internal ?? 20}
                          value={entry.internal}
                          onChange={(e) =>
                            handleInputChange(student.id, 'internal', e.target.value)
                          }
                          className="w-full px-2.5 py-1.5 text-xs bg-slate-100 border-none rounded-lg font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      </td>

                      {/* External Input */}
                      <td className="py-2 px-3">
                        <input
                          type="number"
                          min={0}
                          max={currentSubject?.max_external ?? 80}
                          value={entry.external}
                          onChange={(e) =>
                            handleInputChange(student.id, 'external', e.target.value)
                          }
                          className="w-full px-2.5 py-1.5 text-xs bg-slate-100 border-none rounded-lg font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                      </td>

                      {/* Practical Input */}
                      {currentSubject?.has_practical && (
                        <td className="py-2 px-3">
                          <input
                            type="number"
                            min={0}
                            max={currentSubject?.max_practical ?? 20}
                            value={entry.practical}
                            onChange={(e) =>
                              handleInputChange(student.id, 'practical', e.target.value)
                            }
                            className="w-full px-2.5 py-1.5 text-xs bg-slate-100 border-none rounded-lg font-bold text-slate-900 focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                          />
                        </td>
                      )}

                      {/* Total */}
                      <td className="py-2 px-3 font-black text-slate-900 text-sm">
                        {totalObtained}{' '}
                        <span className="text-[10px] font-normal text-slate-400">
                          / {maxTotal}
                        </span>
                      </td>

                      {/* Percentage */}
                      <td className="py-2 px-3 font-semibold text-slate-700">{pct}%</td>

                      {/* Grade Badge */}
                      <td className="py-2 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-md font-extrabold text-[10px] ${
                            grade === 'A+' || grade === 'A'
                              ? 'bg-emerald-100 text-emerald-700'
                              : grade === 'F'
                              ? 'bg-amber-100 text-amber-700'
                              : 'bg-blue-100 text-blue-700'
                          }`}
                        >
                          {grade}
                        </span>
                      </td>

                      {/* Pass / Fail */}
                      <td className="py-2 px-3">
                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            isPass
                              ? 'bg-emerald-100 text-emerald-700'
                              : 'bg-amber-100 text-amber-700'
                          }`}
                        >
                          {isPass ? 'PASS' : 'FAIL'}
                        </span>
                      </td>

                      {/* Remarks */}
                      <td className="py-2 px-4">
                        <input
                          type="text"
                          placeholder="Teacher remarks..."
                          value={entry.remarks}
                          onChange={(e) =>
                            handleInputChange(student.id, 'remarks', e.target.value)
                          }
                          className="w-full px-2.5 py-1.5 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
                        />
                        {entry.error && (
                          <span className="block text-[10px] text-rose-600 font-semibold mt-0.5">
                            {entry.error}
                          </span>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
