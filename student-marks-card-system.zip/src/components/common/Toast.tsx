import React from 'react';
import { useApp } from '../../context/AppContext';
import { CheckCircle2, AlertCircle, Info, AlertTriangle, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const ToastContainer: React.FC = () => {
  const { toasts, removeToast } = useApp();

  return (
    <div className="fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-md w-full px-4 pointer-events-none">
      <AnimatePresence>
        {toasts.map((toast) => {
          const icon =
            toast.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0" />
            ) : toast.type === 'error' ? (
              <AlertCircle className="w-5 h-5 text-rose-500 shrink-0" />
            ) : toast.type === 'warning' ? (
              <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0" />
            ) : (
              <Info className="w-5 h-5 text-blue-500 shrink-0" />
            );

          const borderColors =
            toast.type === 'success'
              ? 'border-emerald-200 bg-emerald-50/95 text-emerald-950 dark:bg-emerald-950/90 dark:text-emerald-100 dark:border-emerald-800'
              : toast.type === 'error'
              ? 'border-rose-200 bg-rose-50/95 text-rose-950 dark:bg-rose-950/90 dark:text-rose-100 dark:border-rose-800'
              : toast.type === 'warning'
              ? 'border-amber-200 bg-amber-50/95 text-amber-950 dark:bg-amber-950/90 dark:text-amber-100 dark:border-amber-800'
              : 'border-blue-200 bg-blue-50/95 text-blue-950 dark:bg-blue-950/90 dark:text-blue-100 dark:border-blue-800';

          return (
            <motion.div
              key={toast.id}
              initial={{ opacity: 0, y: 20, scale: 0.95 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, scale: 0.9, y: 10 }}
              className={`pointer-events-auto flex items-start justify-between gap-3 p-4 rounded-xl border shadow-lg backdrop-blur-md transition-all ${borderColors}`}
            >
              <div className="flex items-start gap-3">
                {icon}
                <div>
                  <h4 className="text-sm font-semibold leading-tight">{toast.title}</h4>
                  {toast.message && (
                    <p className="text-xs opacity-85 mt-0.5 leading-snug">{toast.message}</p>
                  )}
                </div>
              </div>
              <button
                onClick={() => removeToast(toast.id)}
                className="p-1 rounded-md opacity-60 hover:opacity-100 hover:bg-black/5 transition"
              >
                <X className="w-4 h-4" />
              </button>
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
};
