import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { useApp } from '../../context/AppContext';
import {
  Search,
  RotateCcw,
  LogOut,
  GraduationCap,
  Menu,
  ChevronDown,
  User,
  Sparkles,
} from 'lucide-react';

interface NavbarProps {
  onToggleSidebar: () => void;
  onSelectStudentForCard?: (studentId: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleSidebar, onSelectStudentForCard }) => {
  const { user, logout } = useAuth();
  const { settings, students, resetDatabase, showToast } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [showSearchResults, setShowSearchResults] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  const filteredStudents = searchQuery.trim()
    ? students.filter(
        (s) =>
          s.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.student_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
          s.roll_number.includes(searchQuery)
      )
    : [];

  const handleResetData = async () => {
    if (window.confirm('Reset database to original sample records? Custom additions will be replaced.')) {
      await resetDatabase();
    }
  };

  return (
    <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-8 shrink-0 sticky top-0 z-30 shadow-2xs">
      <div className="flex items-center justify-between gap-4 w-full max-w-7xl mx-auto">
        {/* Left: Breadcrumbs & Mobile Toggle */}
        <div className="flex items-center gap-3">
          <button
            onClick={onToggleSidebar}
            className="p-2 text-slate-600 hover:bg-slate-100 rounded-lg lg:hidden transition"
            title="Toggle Menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="hidden sm:flex items-center gap-2 text-sm text-slate-500 font-medium">
            <span className="hover:text-blue-600 cursor-pointer transition">Management</span>
            <span className="text-slate-300">/</span>
            <span className="text-slate-900 font-semibold">Academic Portal</span>
          </div>
        </div>

        {/* Center: Search input matching design theme */}
        <div className="relative flex-1 max-w-xs sm:max-w-md">
          <div className="relative">
            <input
              type="text"
              placeholder="Search records..."
              value={searchQuery}
              onChange={(e) => {
                setSearchQuery(e.target.value);
                setShowSearchResults(true);
              }}
              onFocus={() => setShowSearchResults(true)}
              className="pl-10 pr-4 py-2 bg-slate-100 border-none rounded-full text-sm w-full focus:ring-2 focus:ring-blue-500 focus:outline-none transition"
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-4 top-2.5 pointer-events-none" />
          </div>

          {/* Quick Search Results Dropdown */}
          {showSearchResults && searchQuery.trim().length > 0 && (
            <div
              className="absolute left-0 right-0 top-full mt-2 bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden z-50 max-h-72 overflow-y-auto"
              onMouseLeave={() => setShowSearchResults(false)}
            >
              <div className="px-3 py-2 bg-slate-50 border-b text-xs font-semibold text-slate-500 flex justify-between">
                <span>Student Results ({filteredStudents.length})</span>
                <button
                  onClick={() => setShowSearchResults(false)}
                  className="hover:text-slate-800"
                >
                  Close
                </button>
              </div>

              {filteredStudents.length === 0 ? (
                <div className="p-4 text-center text-xs text-slate-500">
                  No students found matching "{searchQuery}"
                </div>
              ) : (
                filteredStudents.map((student) => (
                  <div
                    key={student.id}
                    onClick={() => {
                      if (onSelectStudentForCard) {
                        onSelectStudentForCard(student.id);
                      } else {
                        showToast('Student Selected', `${student.name} (${student.class}-${student.section})`);
                      }
                      setSearchQuery('');
                      setShowSearchResults(false);
                    }}
                    className="flex items-center gap-3 px-4 py-2.5 hover:bg-slate-50 cursor-pointer transition border-b border-slate-100 last:border-0"
                  >
                    <img
                      src={
                        student.photo ||
                        'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100'
                      }
                      alt={student.name}
                      className="w-8 h-8 rounded-full object-cover border border-slate-200"
                    />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-semibold text-slate-900 truncate">
                        {student.name}
                      </div>
                      <div className="text-xs text-slate-500">
                        ID: {student.student_id} | Roll: {student.roll_number} | Class: {student.class}-{student.section}
                      </div>
                    </div>
                    <span className="text-xs font-medium text-blue-600 bg-blue-50 px-2 py-0.5 rounded-md">
                      View
                    </span>
                  </div>
                ))
              )}
            </div>
          )}
        </div>

        {/* Right: Academic Year Badge & User Profile */}
        <div className="flex items-center gap-4 sm:gap-6 shrink-0">
          <div className="hidden md:flex items-center gap-4">
            <div className="w-px h-6 bg-slate-200"></div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest">
              AY {settings?.academic_year_current || '2025-2026'}
            </span>
          </div>

          {/* User Menu Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowUserMenu(!showUserMenu)}
              className="flex items-center gap-2 p-1.5 sm:px-3 sm:py-1.5 rounded-lg border border-slate-200 hover:bg-slate-50 transition cursor-pointer"
            >
              <img
                src={
                  user?.avatar ||
                  'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100'
                }
                alt={user?.name}
                className="w-7 h-7 rounded-full object-cover"
              />
              <div className="hidden md:block text-left">
                <div className="text-xs font-bold text-slate-900 leading-tight">
                  {user?.name || 'Admin User'}
                </div>
                <div className="text-[10px] text-slate-500 font-semibold">{user?.role || 'Administrator'}</div>
              </div>
              <ChevronDown className="w-3.5 h-3.5 text-slate-400 hidden sm:block" />
            </button>

            {showUserMenu && (
              <div
                className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 overflow-hidden z-50"
                onMouseLeave={() => setShowUserMenu(false)}
              >
                <div className="p-4 bg-slate-50 border-b border-slate-100">
                  <p className="text-xs font-bold text-slate-900">{user?.name}</p>
                  <p className="text-xs text-slate-500 truncate">{user?.email}</p>
                  <span className="inline-block mt-2 px-2 py-0.5 text-[10px] font-bold bg-blue-100 text-blue-800 rounded-md">
                    Role: {user?.role}
                  </span>
                </div>

                <div className="p-1">
                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      handleResetData();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-slate-700 hover:bg-slate-100 rounded-lg transition"
                  >
                    <RotateCcw className="w-4 h-4 text-slate-500" />
                    <span>Reset Sample Records</span>
                  </button>

                  <button
                    onClick={() => {
                      setShowUserMenu(false);
                      logout();
                    }}
                    className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-rose-600 hover:bg-rose-50 rounded-lg transition font-medium"
                  >
                    <LogOut className="w-4 h-4" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
