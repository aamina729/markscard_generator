import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { Student, StudentReportCard } from '../../types';
import {
  User,
  Phone,
  Mail,
  MapPin,
  Calendar,
  Award,
  GraduationCap,
  FileCheck2,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
} from 'lucide-react';

interface StudentProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  student: Student | null;
  onOpenMarksCard: (studentId: string) => void;
}

export const StudentProfileModal: React.FC<StudentProfileModalProps> = ({
  isOpen,
  onClose,
  student,
  onOpenMarksCard,
}) => {
  const [report, setReport] = useState<StudentReportCard | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (student && isOpen) {
      setLoading(true);
      fetch(`/api/markscard/${student.id}`)
        .then((res) => res.json())
        .then((data) => setReport(data))
        .catch((err) => console.error('Error loading report card:', err))
        .finally(() => setLoading(false));
    }
  }, [student, isOpen]);

  if (!student) return null;

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title="Student Academic Profile"
      subtitle={`Student ID: ${student.student_id}`}
      maxWidth="4xl"
    >
      <div className="space-y-6">
        {/* Student Profile Header Card */}
        <div className="p-6 bg-linear-to-r from-slate-900 to-blue-950 text-white rounded-2xl shadow-md flex flex-col md:flex-row items-center gap-6">
          <img
            src={
              student.photo ||
              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200'
            }
            alt={student.name}
            className="w-24 h-24 rounded-2xl object-cover border-4 border-white/20 shadow-xl"
          />

          <div className="flex-1 text-center md:text-left">
            <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mb-1">
              <h2 className="text-xl font-bold">{student.name}</h2>
              <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-blue-500/30 text-blue-200 border border-blue-400/30">
                {student.class} - {student.section}
              </span>
            </div>

            <p className="text-xs text-slate-300">
              Roll No: <span className="font-bold text-white">{student.roll_number}</span> | Academic Year: {student.academic_year || '2025-2026'}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-1.5 mt-3 text-xs text-slate-300">
              <p className="flex items-center gap-1.5 justify-center md:justify-start">
                <User className="w-3.5 h-3.5 text-blue-400" /> Parent: {student.parent_name || 'N/A'}
              </p>
              <p className="flex items-center gap-1.5 justify-center md:justify-start">
                <Phone className="w-3.5 h-3.5 text-emerald-400" /> Phone: {student.phone || 'N/A'}
              </p>
              <p className="flex items-center gap-1.5 justify-center md:justify-start">
                <Calendar className="w-3.5 h-3.5 text-purple-400" /> DOB: {student.dob || 'N/A'}
              </p>
              <p className="flex items-center gap-1.5 justify-center md:justify-start">
                <MapPin className="w-3.5 h-3.5 text-rose-400" /> Address: {student.address || 'N/A'}
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              onClose();
              onOpenMarksCard(student.id);
            }}
            className="px-5 py-3 bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs rounded-xl shadow-lg transition flex items-center gap-2 shrink-0 border border-blue-400/40 cursor-pointer"
          >
            <FileCheck2 className="w-4 h-4" />
            <span>Generate Marks Card</span>
          </button>
        </div>

        {/* Academic Performance Overview */}
        {loading ? (
          <div className="p-8 text-center text-xs text-slate-500">
            Computing student academic records...
          </div>
        ) : report ? (
          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
              <Award className="w-4 h-4 text-amber-500" />
              <span>Current Evaluation Summary</span>
            </h3>

            {/* Performance Metric Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <p className="text-[10px] font-bold text-slate-500 uppercase">Total Score</p>
                <p className="text-lg font-black text-slate-900 mt-0.5">
                  {report.totalObtainedMarks} / {report.totalMaxMarks}
                </p>
                <p className="text-[10px] text-slate-500">{report.overallPercentage}% Aggregate</p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <p className="text-[10px] font-bold text-slate-500 uppercase">Overall Grade & GPA</p>
                <p className="text-lg font-black text-blue-600 mt-0.5">
                  {report.overallGrade} <span className="text-xs font-semibold text-slate-500">({report.overallGPA} GPA)</span>
                </p>
                <p className="text-[10px] text-slate-500">Academic Standing</p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <p className="text-[10px] font-bold text-slate-500 uppercase">Class Rank</p>
                <p className="text-lg font-black text-amber-600 mt-0.5">
                  #{report.classRank} <span className="text-xs font-normal text-slate-500">of {report.totalStudentsInClass}</span>
                </p>
                <p className="text-[10px] text-slate-500">In {student.class}-{student.section}</p>
              </div>

              <div className="p-3.5 bg-slate-50 rounded-xl border border-slate-200">
                <p className="text-[10px] font-bold text-slate-500 uppercase">Final Result</p>
                <div className="mt-0.5">
                  <span
                    className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-black ${
                      report.result === 'PASS'
                        ? 'bg-emerald-100 text-emerald-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {report.result === 'PASS' ? (
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                    ) : (
                      <XCircle className="w-3.5 h-3.5 text-rose-600" />
                    )}
                    {report.result}
                  </span>
                </div>
              </div>
            </div>

            {/* Subject Breakdown Table */}
            <div className="overflow-x-auto border border-slate-200 rounded-xl">
              <table className="w-full text-left text-xs">
                <thead>
                  <tr className="bg-slate-100 text-slate-700 font-bold border-b border-slate-200">
                    <th className="p-3">Subject Code & Name</th>
                    <th className="p-3">Internal</th>
                    <th className="p-3">External</th>
                    <th className="p-3">Practical</th>
                    <th className="p-3">Total / Max</th>
                    <th className="p-3">Grade</th>
                    <th className="p-3">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {report.subjectResults.map((item, idx) => (
                    <tr key={idx} className="hover:bg-slate-50 transition">
                      <td className="p-3 font-semibold text-slate-900">
                        {item.subject.subject_name}
                        <span className="block text-[10px] font-mono text-slate-400">
                          {item.subject.subject_code}
                        </span>
                      </td>
                      <td className="p-3 text-slate-700">{item.internal}</td>
                      <td className="p-3 text-slate-700">{item.external}</td>
                      <td className="p-3 text-slate-700">{item.subject.has_practical ? item.practical : 'N/A'}</td>
                      <td className="p-3 font-bold text-slate-900">
                        {item.totalObtained} / {item.maxMarks}
                      </td>
                      <td className="p-3 font-bold text-blue-600">{item.grade}</td>
                      <td className="p-3">
                        <span
                          className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                            item.passStatus === 'Pass'
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-rose-100 text-rose-800'
                          }`}
                        >
                          {item.passStatus}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ) : null}
      </div>
    </Modal>
  );
};
