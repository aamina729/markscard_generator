import React, { useState, useEffect } from 'react';
import { Modal } from '../common/Modal';
import { Student } from '../../types';
import { User, Phone, Mail, MapPin, Calendar, Hash, Bookmark } from 'lucide-react';

interface StudentFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: Omit<Student, 'id'>) => Promise<boolean>;
  initialData?: Student | null;
}

export const StudentFormModal: React.FC<StudentFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  initialData,
}) => {
  const [formData, setFormData] = useState<Omit<Student, 'id'>>({
    student_id: '',
    roll_number: '',
    name: '',
    gender: 'Male',
    dob: '2010-01-01',
    class: 'Class 10',
    section: 'A',
    academic_year: '2025-2026',
    parent_name: '',
    phone: '',
    email: '',
    address: '',
    photo: '',
  });

  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (initialData) {
      setFormData({
        student_id: initialData.student_id,
        roll_number: initialData.roll_number,
        name: initialData.name,
        gender: initialData.gender,
        dob: initialData.dob,
        class: initialData.class,
        section: initialData.section,
        academic_year: initialData.academic_year || '2025-2026',
        parent_name: initialData.parent_name,
        phone: initialData.phone,
        email: initialData.email || '',
        address: initialData.address,
        photo: initialData.photo || '',
      });
    } else {
      setFormData({
        student_id: `STU-2026-${Math.floor(100 + Math.random() * 800)}`,
        roll_number: `${Math.floor(100 + Math.random() * 90)}`,
        name: '',
        gender: 'Male',
        dob: '2010-05-15',
        class: 'Class 10',
        section: 'A',
        academic_year: '2025-2026',
        parent_name: '',
        phone: '+91 ',
        email: '',
        address: '',
        photo: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&auto=format&fit=crop&q=80',
      });
    }
  }, [initialData, isOpen]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.student_id.trim() || !formData.roll_number.trim()) {
      alert('Please fill in required fields (Name, Student ID, Roll Number)');
      return;
    }
    setSaving(true);
    const success = await onSubmit(formData);
    setSaving(false);
    if (success) {
      onClose();
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={onClose}
      title={initialData ? 'Edit Student Record' : 'Add New Student'}
      subtitle="Complete student academic and personal information"
      maxWidth="2xl"
    >
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Photo Preview & URL */}
        <div className="flex items-center gap-4 p-3 bg-slate-50 rounded-xl border border-slate-200">
          <img
            src={
              formData.photo ||
              'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200'
            }
            alt="Student Avatar"
            className="w-16 h-16 rounded-xl object-cover border-2 border-white shadow-xs"
          />
          <div className="flex-1">
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Student Photo URL
            </label>
            <input
              type="text"
              placeholder="https://images.unsplash.com/..."
              value={formData.photo}
              onChange={(e) => setFormData({ ...formData, photo: e.target.value })}
              className="w-full px-3 py-1.5 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Full Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Full Name *
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                required
                placeholder="e.g. Aarav Sharma"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Student ID */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Student ID *
            </label>
            <div className="relative">
              <Hash className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                required
                placeholder="STU-2026-101"
                value={formData.student_id}
                onChange={(e) => setFormData({ ...formData, student_id: e.target.value })}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none font-mono"
              />
            </div>
          </div>

          {/* Roll Number */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Roll Number *
            </label>
            <input
              type="text"
              required
              placeholder="101"
              value={formData.roll_number}
              onChange={(e) => setFormData({ ...formData, roll_number: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          {/* Gender */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Gender</label>
            <select
              value={formData.gender}
              onChange={(e) => setFormData({ ...formData, gender: e.target.value as any })}
              className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            >
              <option value="Male">Male</option>
              <option value="Female">Female</option>
              <option value="Other">Other</option>
            </select>
          </div>

          {/* Class */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Class</label>
            <select
              value={formData.class}
              onChange={(e) => setFormData({ ...formData, class: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            >
              <option value="Class 9">Class 9</option>
              <option value="Class 10">Class 10</option>
              <option value="Class 11">Class 11</option>
              <option value="Class 12">Class 12</option>
            </select>
          </div>

          {/* Section */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Section</label>
            <select
              value={formData.section}
              onChange={(e) => setFormData({ ...formData, section: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            >
              <option value="A">Section A</option>
              <option value="B">Section B</option>
              <option value="C">Section C</option>
              <option value="D">Section D</option>
            </select>
          </div>

          {/* Academic Year */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Academic Year</label>
            <input
              type="text"
              placeholder="2025-2026"
              value={formData.academic_year}
              onChange={(e) => setFormData({ ...formData, academic_year: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          {/* DOB */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Date of Birth</label>
            <input
              type="date"
              value={formData.dob}
              onChange={(e) => setFormData({ ...formData, dob: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          {/* Parent Name */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Parent / Guardian Name
            </label>
            <input
              type="text"
              placeholder="Rajesh Sharma"
              value={formData.parent_name}
              onChange={(e) => setFormData({ ...formData, parent_name: e.target.value })}
              className="w-full px-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>

          {/* Phone */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Contact Phone</label>
            <div className="relative">
              <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="+91 98765-43210"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full pl-9 pr-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Address */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">Residential Address</label>
          <div className="relative">
            <MapPin className="absolute left-3 top-3 w-4 h-4 text-slate-400" />
            <textarea
              rows={2}
              placeholder="Street address, city, state and postal code"
              value={formData.address}
              onChange={(e) => setFormData({ ...formData, address: e.target.value })}
              className="w-full pl-9 pr-3 py-2 text-xs bg-slate-100 border-none rounded-lg focus:bg-white focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>
        </div>

        {/* Submit Actions */}
        <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-100">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-slate-200 text-slate-700 text-xs font-bold rounded-xl hover:bg-slate-50 transition"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={saving}
            className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl shadow-md transition disabled:opacity-50"
          >
            {saving ? 'Saving...' : initialData ? 'Update Record' : 'Save Student'}
          </button>
        </div>
      </form>
    </Modal>
  );
};
