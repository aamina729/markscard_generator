import React, { useState, useEffect } from 'react';
import { useApp } from '../../context/AppContext';
import { StudentReportCard, Student } from '../../types';
import { MarksCardDocument } from './MarksCardDocument';
import {
  FileCheck2,
  Download,
  Printer,
  Search,
  Users,
  Palette,
  Sparkles,
  ChevronRight,
  Layers,
} from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

interface MarksCardPreviewProps {
  initialStudentId?: string;
}

export const MarksCardPreview: React.FC<MarksCardPreviewProps> = ({ initialStudentId }) => {
  const { students, settings, showToast } = useApp();

  const [selectedStudentId, setSelectedStudentId] = useState<string>(
    initialStudentId || students[0]?.id || ''
  );

  const [report, setReport] = useState<StudentReportCard | null>(null);
  const [loading, setLoading] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [theme, setTheme] = useState<'classic' | 'modern' | 'academic'>(
    settings?.card_theme || 'classic'
  );

  // Bulk Generation Mode
  const [bulkMode, setBulkMode] = useState(false);
  const [bulkClass, setBulkClass] = useState('Class 10');
  const [bulkSection, setBulkSection] = useState('A');
  const [bulkReports, setBulkReports] = useState<StudentReportCard[]>([]);

  useEffect(() => {
    if (initialStudentId) {
      setSelectedStudentId(initialStudentId);
    }
  }, [initialStudentId]);

  // Fetch report for single selected student
  useEffect(() => {
    if (!selectedStudentId || bulkMode) return;
    setLoading(true);
    fetch(`/api/markscard/${selectedStudentId}`)
      .then((res) => res.json())
      .then((data) => setReport(data))
      .catch((err) => console.error('Error fetching markscard:', err))
      .finally(() => setLoading(false));
  }, [selectedStudentId, bulkMode]);

  // Fetch report cards for bulk mode
  useEffect(() => {
    if (!bulkMode) return;
    setLoading(true);
    const targetStudents = students.filter(
      (s) => s.class === bulkClass && s.section === bulkSection
    );

    Promise.all(targetStudents.map((st) => fetch(`/api/markscard/${st.id}`).then((r) => r.json())))
      .then((data) => setBulkReports(data))
      .catch((err) => console.error('Error bulk loading:', err))
      .finally(() => setLoading(false));
  }, [bulkMode, bulkClass, bulkSection, students]);

  // PDF Export single card
  const handleDownloadPDF = async () => {
    if (!report || !settings) return;
    const element = document.getElementById(`marks-card-document-${report.student.id}`);
    if (!element) return;

    setDownloading(true);
    showToast('Generating PDF', 'Preparing high resolution printable PDF...');

    try {
      const canvas = await html2canvas(element, {
        scale: 2,
        useCORS: true,
        logging: false,
        backgroundColor: '#ffffff',
      });

      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save(`MarksCard_${report.student.name.replace(/\s+/g, '_')}_${report.student.student_id}.pdf`);

      showToast('PDF Downloaded', `Marks card for ${report.student.name} saved successfully`);
    } catch (err) {
      console.error('PDF Generation Error:', err);
      showToast('Error', 'Failed to generate PDF document', 'error');
    } finally {
      setDownloading(false);
    }
  };

  // Browser Print
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
        <div>
          <h1 className="text-xl font-bold text-slate-900 tracking-tight">
            Marks Card Generator
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Preview, customize design theme, and download print-ready A4 PDF marks cards
          </p>
        </div>

        {/* Mode Switcher Buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setBulkMode(false)}
            className={`px-3 py-2 text-xs font-bold rounded-xl transition cursor-pointer ${
              !bulkMode
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            Single Student Card
          </button>
          <button
            onClick={() => setBulkMode(true)}
            className={`px-3 py-2 text-xs font-bold rounded-xl transition cursor-pointer flex items-center gap-1.5 ${
              bulkMode
                ? 'bg-blue-600 text-white shadow-md'
                : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Class Bulk Cards</span>
          </button>
        </div>
      </div>

      {/* Selector & Actions Bar */}
      <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-wrap items-center justify-between gap-4 print:hidden">
        {!bulkMode ? (
          // Single Student Selector
          <div className="flex flex-wrap items-center gap-3 text-xs flex-1 max-w-xl">
            <label className="font-bold text-slate-700 shrink-0">Select Student:</label>
            <select
              value={selectedStudentId}
              onChange={(e) => setSelectedStudentId(e.target.value)}
              className="flex-1 px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              {students.map((st) => (
                <option key={st.id} value={st.id}>
                  {st.name} ({st.class}-{st.section} | ID: {st.student_id})
                </option>
              ))}
            </select>
          </div>
        ) : (
          // Bulk Class Selector
          <div className="flex flex-wrap items-center gap-3 text-xs">
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Class
              </label>
              <select
                value={bulkClass}
                onChange={(e) => setBulkClass(e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-blue-500"
              >
                <option value="Class 9">Class 9</option>
                <option value="Class 10">Class 10</option>
                <option value="Class 11">Class 11</option>
                <option value="Class 12">Class 12</option>
              </select>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                Section
              </label>
              <select
                value={bulkSection}
                onChange={(e) => setBulkSection(e.target.value)}
                className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-lg font-bold text-slate-900 focus:ring-2 focus:ring-blue-500"
              >
                <option value="A">Section A</option>
                <option value="B">Section B</option>
                <option value="C">Section C</option>
              </select>
            </div>
          </div>
        )}

        {/* Theme Picker & Download/Print Controls */}
        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-1 text-xs bg-slate-50 border border-slate-200 p-1 rounded-lg">
            <Palette className="w-3.5 h-3.5 text-slate-500 ml-1" />
            <button
              onClick={() => setTheme('classic')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                theme === 'classic' ? 'bg-white shadow-xs font-bold text-blue-700' : 'text-slate-600'
              }`}
            >
              Classic
            </button>
            <button
              onClick={() => setTheme('modern')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                theme === 'modern' ? 'bg-white shadow-xs font-bold text-blue-700' : 'text-slate-600'
              }`}
            >
              Modern
            </button>
            <button
              onClick={() => setTheme('academic')}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold transition-colors ${
                theme === 'academic' ? 'bg-white shadow-xs font-bold text-blue-700' : 'text-slate-600'
              }`}
            >
              Academic
            </button>
          </div>

          <button
            onClick={handlePrint}
            className="px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Printer className="w-4 h-4" />
            <span>Print</span>
          </button>

          {!bulkMode && (
            <button
              onClick={handleDownloadPDF}
              disabled={downloading || !report}
              className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl shadow-md transition-colors flex items-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{downloading ? 'Exporting...' : 'Download PDF'}</span>
            </button>
          )}
        </div>
      </div>

      {/* Document Canvas Preview */}
      {loading ? (
        <div className="p-12 text-center text-xs font-semibold text-slate-500">
          Generating high resolution academic marks card preview...
        </div>
      ) : settings && !bulkMode && report ? (
        <div className="bg-slate-200/60 p-4 sm:p-8 rounded-2xl border border-slate-300/80 shadow-inner overflow-x-auto print:bg-white print:p-0 print:border-0">
          <MarksCardDocument report={report} settings={settings} theme={theme} />
        </div>
      ) : settings && bulkMode ? (
        <div className="space-y-8 bg-slate-200/60 p-4 sm:p-8 rounded-2xl border border-slate-300/80 shadow-inner overflow-x-auto print:bg-white print:p-0 print:border-0">
          <div className="p-4 bg-white rounded-xl text-xs font-semibold text-slate-700 border flex justify-between items-center print:hidden">
            <span>
              Generating {bulkReports.length} Marks Cards for {bulkClass}-{bulkSection}
            </span>
            <button
              onClick={handlePrint}
              className="px-3 py-1.5 bg-blue-600 text-white rounded-lg font-bold"
            >
              Print Entire Class Batch
            </button>
          </div>

          {bulkReports.map((singleReport) => (
            <div key={singleReport.student.id} className="page-break-after">
              <MarksCardDocument report={singleReport} settings={settings} theme={theme} />
            </div>
          ))}
        </div>
      ) : null}
    </div>
  );
};
