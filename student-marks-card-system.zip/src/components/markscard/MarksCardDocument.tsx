import React from 'react';
import { StudentReportCard, SchoolSettings } from '../../types';
import { Award, CheckCircle2, XCircle, GraduationCap, ShieldCheck } from 'lucide-react';

interface MarksCardDocumentProps {
  report: StudentReportCard;
  settings: SchoolSettings;
  theme?: 'classic' | 'modern' | 'academic';
}

export const MarksCardDocument: React.FC<MarksCardDocumentProps> = ({
  report,
  settings,
  theme = 'classic',
}) => {
  const { student, subjectResults } = report;

  // Theme styling
  const themeContainerBorder =
    theme === 'academic'
      ? 'border-4 border-double border-blue-900 bg-white'
      : theme === 'modern'
      ? 'border border-slate-300 bg-slate-50/50 rounded-2xl shadow-xl'
      : 'border-2 border-slate-900 bg-white'; // classic

  const headerBg =
    theme === 'academic'
      ? 'bg-blue-900 text-white p-6'
      : theme === 'modern'
      ? 'bg-linear-to-r from-slate-900 to-blue-900 text-white p-6 rounded-t-xl'
      : 'border-b-2 border-slate-900 p-6 bg-slate-50'; // classic

  return (
    <div
      id={`marks-card-document-${student.id}`}
      className={`relative w-full max-w-[210mm] mx-auto p-8 text-slate-900 font-sans print:shadow-none print:p-0 print:border-none ${themeContainerBorder}`}
      style={{ minHeight: '297mm' }}
    >
      {/* Decorative Outer Border for Classic/Academic */}
      {theme !== 'modern' && (
        <div className="absolute inset-2 border border-slate-300 pointer-events-none" />
      )}

      {/* Background Watermark Seal */}
      <div className="absolute inset-0 flex items-center justify-center opacity-[0.03] pointer-events-none select-none">
        <GraduationCap className="w-96 h-96 text-slate-900" />
      </div>

      <div className="relative z-10 space-y-6">
        {/* Header Section */}
        <div className={`flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left ${headerBg}`}>
          <div className="flex items-center gap-4">
            <img
              src={settings.logo_url}
              alt="School Logo"
              className="w-16 h-16 rounded-xl object-cover border-2 border-white/40 shadow-sm shrink-0"
            />
            <div>
              <h1 className="text-xl sm:text-2xl font-black tracking-tight leading-tight uppercase">
                {settings.school_name}
              </h1>
              <p className="text-xs opacity-90 font-medium">{settings.address}, {settings.city_state_zip}</p>
              <p className="text-[10px] opacity-80 mt-0.5">
                Affiliation No: <span className="font-bold">{settings.affiliation_no}</span> | School Code: <span className="font-bold">{settings.school_code}</span>
              </p>
            </div>
          </div>

          <div className="text-center sm:text-right shrink-0">
            <span className="inline-block px-3 py-1 bg-amber-400 text-amber-950 font-black text-xs uppercase tracking-widest rounded-md shadow-xs mb-1">
              Official Marks Card
            </span>
            <p className="text-xs font-bold opacity-90">Academic Session {report.academic_year}</p>
          </div>
        </div>

        {/* Student Information Box */}
        <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          <div className="flex justify-center md:justify-start">
            <img
              src={
                student.photo ||
                'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200'
              }
              alt={student.name}
              className="w-20 h-20 rounded-xl object-cover border-2 border-slate-300 shadow-xs"
            />
          </div>

          <div className="md:col-span-3 grid grid-cols-2 sm:grid-cols-3 gap-x-4 gap-y-2 text-xs">
            <div>
              <span className="block text-[10px] font-bold text-slate-400 uppercase">Student Name</span>
              <span className="font-extrabold text-slate-900 text-sm">{student.name}</span>
            </div>

            <div>
              <span className="block text-[10px] font-bold text-slate-400 uppercase">Student ID</span>
              <span className="font-bold text-slate-800 font-mono">{student.student_id}</span>
            </div>

            <div>
              <span className="block text-[10px] font-bold text-slate-400 uppercase">Roll Number</span>
              <span className="font-bold text-slate-900">{student.roll_number}</span>
            </div>

            <div>
              <span className="block text-[10px] font-bold text-slate-400 uppercase">Class & Section</span>
              <span className="font-bold text-blue-800">{student.class} - {student.section}</span>
            </div>

            <div>
              <span className="block text-[10px] font-bold text-slate-400 uppercase">Parent / Guardian</span>
              <span className="font-semibold text-slate-800">{student.parent_name || 'N/A'}</span>
            </div>

            <div>
              <span className="block text-[10px] font-bold text-slate-400 uppercase">Date of Birth</span>
              <span className="font-semibold text-slate-800">{student.dob || 'N/A'}</span>
            </div>
          </div>
        </div>

        {/* Marks Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border border-slate-300">
            <thead>
              <tr className="bg-slate-800 text-white font-bold text-[11px] uppercase tracking-wider">
                <th className="p-2.5 border-r border-slate-700">Code</th>
                <th className="p-2.5 border-r border-slate-700">Subject Name</th>
                <th className="p-2.5 border-r border-slate-700 text-center">Max Marks</th>
                <th className="p-2.5 border-r border-slate-700 text-center">Internal</th>
                <th className="p-2.5 border-r border-slate-700 text-center">External</th>
                <th className="p-2.5 border-r border-slate-700 text-center">Practical</th>
                <th className="p-2.5 border-r border-slate-700 text-center">Total Obtained</th>
                <th className="p-2.5 border-r border-slate-700 text-center">Grade</th>
                <th className="p-2.5 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {subjectResults.map((item, idx) => (
                <tr key={idx} className={idx % 2 === 0 ? 'bg-white' : 'bg-slate-50/60'}>
                  <td className="p-2.5 border-r border-slate-200 font-mono font-bold text-slate-700">
                    {item.subject.subject_code}
                  </td>
                  <td className="p-2.5 border-r border-slate-200 font-bold text-slate-900">
                    {item.subject.subject_name}
                  </td>
                  <td className="p-2.5 border-r border-slate-200 text-center font-medium">
                    {item.maxMarks}
                  </td>
                  <td className="p-2.5 border-r border-slate-200 text-center">{item.internal}</td>
                  <td className="p-2.5 border-r border-slate-200 text-center">{item.external}</td>
                  <td className="p-2.5 border-r border-slate-200 text-center">
                    {item.subject.has_practical ? item.practical : '-'}
                  </td>
                  <td className="p-2.5 border-r border-slate-200 text-center font-black text-slate-900 text-sm">
                    {item.totalObtained}
                  </td>
                  <td className="p-2.5 border-r border-slate-200 text-center font-black text-blue-700 text-sm">
                    {item.grade}
                  </td>
                  <td className="p-2.5 text-center font-bold">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] ${
                        item.passStatus === 'Pass'
                          ? 'text-emerald-800 bg-emerald-100'
                          : 'text-rose-800 bg-rose-100'
                      }`}
                    >
                      {item.passStatus}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-slate-900 text-white font-bold text-xs">
                <td colSpan={2} className="p-3 border-r border-slate-700 uppercase tracking-wider">
                  Grand Aggregate Total
                </td>
                <td className="p-3 border-r border-slate-700 text-center">{report.totalMaxMarks}</td>
                <td colSpan={3} className="p-3 border-r border-slate-700"></td>
                <td className="p-3 border-r border-slate-700 text-center text-sm font-black text-amber-300">
                  {report.totalObtainedMarks}
                </td>
                <td className="p-3 border-r border-slate-700 text-center font-black text-amber-300">
                  {report.overallGrade}
                </td>
                <td className="p-3 text-center">
                  <span
                    className={`px-2.5 py-1 rounded text-xs font-black ${
                      report.result === 'PASS'
                        ? 'bg-emerald-400 text-emerald-950'
                        : 'bg-rose-400 text-rose-950'
                    }`}
                  >
                    {report.result}
                  </span>
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Summary Highlights Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-center">
          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <span className="block text-[10px] font-bold text-slate-400 uppercase">Percentage</span>
            <span className="text-lg font-black text-slate-900">{report.overallPercentage}%</span>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <span className="block text-[10px] font-bold text-slate-400 uppercase">Overall Grade</span>
            <span className="text-lg font-black text-blue-700">{report.overallGrade}</span>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <span className="block text-[10px] font-bold text-slate-400 uppercase">GPA / CGPA</span>
            <span className="text-lg font-black text-indigo-700">{report.overallGPA}</span>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
            <span className="block text-[10px] font-bold text-slate-400 uppercase">Class Rank</span>
            <span className="text-lg font-black text-amber-600">#{report.classRank}</span>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl col-span-2 sm:col-span-1">
            <span className="block text-[10px] font-bold text-slate-400 uppercase">Attendance</span>
            <span className="text-lg font-black text-emerald-700">{report.overallAttendancePct}%</span>
          </div>
        </div>

        {/* Grading Scale Legend */}
        <div className="p-3 bg-slate-100/80 border border-slate-200 rounded-xl text-[10px] text-slate-600 flex flex-wrap items-center justify-between gap-2">
          <span className="font-bold text-slate-800">Grading Scale:</span>
          <span>90-100%: A+ (Outstanding)</span>
          <span>80-89%: A (Excellent)</span>
          <span>70-79%: B+ (Very Good)</span>
          <span>60-69%: B (Good)</span>
          <span>50-59%: C (Satisfactory)</span>
          <span>40-49%: D (Pass)</span>
          <span>&lt;40%: F (Fail)</span>
        </div>

        {/* Signatures & Seal Footer */}
        <div className="pt-8 grid grid-cols-3 gap-6 text-center text-xs">
          <div>
            <div className="h-12 flex items-end justify-center pb-1 font-serif italic text-slate-700 border-b border-slate-400">
              {settings.class_teacher_name}
            </div>
            <p className="mt-1 font-bold text-slate-800">Class Teacher</p>
            <p className="text-[10px] text-slate-500">Authorized Evaluator</p>
          </div>

          <div className="flex flex-col items-center justify-center">
            <img
              src={settings.seal_url}
              alt="School Seal"
              className="w-14 h-14 object-cover opacity-85 rounded-full border border-slate-300 shadow-2xs"
            />
            <p className="mt-1 font-bold text-slate-800 text-[10px]">Official Institutional Seal</p>
          </div>

          <div>
            <div className="h-12 flex items-end justify-center pb-1 font-serif italic text-slate-700 border-b border-slate-400">
              {settings.principal_name}
            </div>
            <p className="mt-1 font-bold text-slate-800">{settings.principal_title}</p>
            <p className="text-[10px] text-slate-500">Date of Issue: {report.issueDate}</p>
          </div>
        </div>
      </div>
    </div>
  );
};
