import React, { useState } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppProvider, useApp } from './context/AppContext';
import { Sidebar, ActiveTab } from './components/common/Sidebar';
import { Navbar } from './components/common/Navbar';
import { ToastContainer } from './components/common/Toast';
import { Dashboard } from './components/dashboard/Dashboard';
import { StudentList } from './components/students/StudentList';
import { SubjectList } from './components/subjects/SubjectList';
import { MarksEntry } from './components/marks/MarksEntry';
import { MarksCardPreview } from './components/markscard/MarksCardPreview';
import { AnalyticsView } from './components/analytics/AnalyticsView';
import { SettingsPage } from './components/settings/SettingsPage';
import { LoginModal } from './components/auth/LoginModal';
import { motion, AnimatePresence } from 'motion/react';

const MainLayout: React.FC = () => {
  const { isAuthenticated, loading: authLoading } = useAuth();
  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [selectedStudentForCard, setSelectedStudentForCard] = useState<string | undefined>(undefined);

  if (authLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-900 text-white">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="text-xs font-semibold text-slate-400">Loading Academic System...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return <LoginModal />;
  }

  const handleOpenMarksCardForStudent = (studentId: string) => {
    setSelectedStudentForCard(studentId);
    setActiveTab('marks-card');
  };

  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-900 font-sans flex flex-col">
      {/* Sidebar */}
      <Sidebar
        activeTab={activeTab}
        onTabChange={(tab) => {
          setActiveTab(tab);
          if (tab !== 'marks-card') setSelectedStudentForCard(undefined);
        }}
        isOpen={sidebarOpen}
        onCloseMobile={() => setSidebarOpen(false)}
      />

      {/* Main Content Area */}
      <div className="lg:pl-64 flex-1 flex flex-col min-w-0">
        <Navbar
          onToggleSidebar={() => setSidebarOpen(!sidebarOpen)}
          onSelectStudentForCard={handleOpenMarksCardForStudent}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.15 }}
            >
              {activeTab === 'dashboard' && (
                <Dashboard
                  onNavigate={(tab) => setActiveTab(tab)}
                  onSelectStudentCard={handleOpenMarksCardForStudent}
                />
              )}

              {activeTab === 'students' && (
                <StudentList onOpenMarksCard={handleOpenMarksCardForStudent} />
              )}

              {activeTab === 'subjects' && <SubjectList />}

              {activeTab === 'marks-entry' && <MarksEntry />}

              {activeTab === 'marks-card' && (
                <MarksCardPreview initialStudentId={selectedStudentForCard} />
              )}

              {activeTab === 'analytics' && <AnalyticsView />}

              {activeTab === 'settings' && <SettingsPage />}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>

      <ToastContainer />
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <AppProvider>
        <MainLayout />
      </AppProvider>
    </AuthProvider>
  );
}
