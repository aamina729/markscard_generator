import { Student, Subject, MarkEntry, SchoolSettings, User, DashboardStats } from '../types';

import {
  initialSchoolSettings,
  initialAdminUser,
  initialSubjects,
  initialStudents,
  initialMarks,
} from './mockData';
import { calculateGrade, calculateSubjectResult } from '../utils/academicUtils';

class AcademicDataStore {
  private settings: SchoolSettings = { ...initialSchoolSettings };
  private currentUser: User | null = { ...initialAdminUser };
  private subjects: Subject[] = [...initialSubjects];
  private students: Student[] = [...initialStudents];
  private marks: MarkEntry[] = [...initialMarks];

  // Reset to initial seed data
  public seed() {
    this.settings = { ...initialSchoolSettings };
    this.subjects = [...initialSubjects];
    this.students = [...initialStudents];
    this.marks = [...initialMarks];
    this.currentUser = { ...initialAdminUser };
  }

  // Auth
  public getCurrentUser(): User | null {
    return this.currentUser;
  }

  public login(username: string, role: string = 'Admin'): User {
    const user: User = {
      id: `usr-${Date.now()}`,
      username: username || 'admin',
      name: username === 'principal' ? 'Dr. Robert Harrison' : username === 'teacher' ? 'Prof. Margaret Sterling' : 'Academic Administrator',
      role: (role as 'Admin' | 'Teacher' | 'Principal') || 'Admin',
      email: `${username || 'admin'}@stxaviersacademy.edu`,
      avatar: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=120&auto=format&fit=crop&q=80',
    };
    this.currentUser = user;
    return user;
  }

  public logout() {
    this.currentUser = null;
  }

  // Settings
  public getSettings(): SchoolSettings {
    return this.settings;
  }

  public updateSettings(newSettings: Partial<SchoolSettings>): SchoolSettings {
    this.settings = { ...this.settings, ...newSettings };
    return this.settings;
  }

  // Students
  public getStudents(): Student[] {
    return this.students;
  }

  public getStudentById(id: string): Student | undefined {
    return this.students.find((s) => s.id === id || s.student_id === id);
  }

  public addStudent(data: Omit<Student, 'id'>): Student {
    const newStudent: Student = {
      ...data,
      id: `stu-${Date.now()}`,
      student_id: data.student_id || `STU-2026-${100 + this.students.length + 1}`,
    };
    this.students.unshift(newStudent);
    return newStudent;
  }

  public updateStudent(id: string, data: Partial<Student>): Student | null {
    const index = this.students.findIndex((s) => s.id === id);
    if (index === -1) return null;
    this.students[index] = { ...this.students[index], ...data };
    return this.students[index];
  }

  public deleteStudent(id: string): boolean {
    const initialLen = this.students.length;
    this.students = this.students.filter((s) => s.id !== id);
    this.marks = this.marks.filter((m) => m.student_id !== id);
    return this.students.length < initialLen;
  }

  // Subjects
  public getSubjects(): Subject[] {
    return this.subjects;
  }

  public getSubjectById(id: string): Subject | undefined {
    return this.subjects.find((s) => s.id === id);
  }

  public addSubject(data: Omit<Subject, 'id'>): Subject {
    const newSubj: Subject = {
      ...data,
      id: `subj-${Date.now()}`,
      subject_code: data.subject_code.toUpperCase(),
    };
    this.subjects.push(newSubj);
    return newSubj;
  }

  public updateSubject(id: string, data: Partial<Subject>): Subject | null {
    const index = this.subjects.findIndex((s) => s.id === id);
    if (index === -1) return null;
    this.subjects[index] = { ...this.subjects[index], ...data };
    return this.subjects[index];
  }

  public deleteSubject(id: string): boolean {
    const initialLen = this.subjects.length;
    this.subjects = this.subjects.filter((s) => s.id !== id);
    this.marks = this.marks.filter((m) => m.subject_id !== id);
    return this.subjects.length < initialLen;
  }

  // Marks
  public getMarks(): MarkEntry[] {
    return this.marks;
  }

  public getStudentMarks(studentId: string): MarkEntry[] {
    return this.marks.filter((m) => m.student_id === studentId);
  }

  public saveOrUpdateMark(
    studentId: string,
    subjectId: string,
    internalMarks: number,
    externalMarks: number,
    practicalMarks: number,
    remarks?: string,
    attendancePct?: number
  ): MarkEntry {
    const subject = this.getSubjectById(subjectId);
    const totalObtained = internalMarks + externalMarks + practicalMarks;
    const maxMarks = subject ? subject.max_marks : 100;
    const percentage = Math.round((totalObtained / maxMarks) * 100 * 100) / 100;
    const { grade, gradePoint, remarks: autoRemarks } = calculateGrade(percentage);
    const passStatus = totalObtained >= (subject?.pass_marks ?? 40) ? 'Pass' : 'Fail';

    const existingIndex = this.marks.findIndex(
      (m) => m.student_id === studentId && m.subject_id === subjectId
    );

    const markPayload: MarkEntry = {
      id: existingIndex >= 0 ? this.marks[existingIndex].id : `m-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      student_id: studentId,
      subject_id: subjectId,
      internal_marks: internalMarks,
      external_marks: externalMarks,
      practical_marks: practicalMarks,
      total_obtained: totalObtained,
      percentage,
      grade,
      grade_point: gradePoint,
      pass_status: passStatus,
      remarks: remarks || autoRemarks,
      attendance_pct: attendancePct ?? 90,
    };

    if (existingIndex >= 0) {
      this.marks[existingIndex] = markPayload;
    } else {
      this.marks.push(markPayload);
    }

    return markPayload;
  }

  // Batch Save Marks
  public saveBatchMarks(entries: Array<{
    student_id: string;
    subject_id: string;
    internal_marks: number;
    external_marks: number;
    practical_marks: number;
    remarks?: string;
    attendance_pct?: number;
  }>): MarkEntry[] {
    return entries.map((entry) =>
      this.saveOrUpdateMark(
        entry.student_id,
        entry.subject_id,
        entry.internal_marks,
        entry.external_marks,
        entry.practical_marks,
        entry.remarks,
        entry.attendance_pct
      )
    );
  }

  // Dashboard Metrics
  public getDashboardStats(): DashboardStats {
    const totalStudents = this.students.length;
    const classesSet = new Set(this.students.map((s) => `${s.class}-${s.section}`));
    const totalClasses = classesSet.size;
    const totalSubjects = this.subjects.length;

    // Student Pass Percentage Calculation
    let totalStudentPass = 0;
    let sumPercentages = 0;

    this.students.forEach((st) => {
      const stMarks = this.marks.filter((m) => m.student_id === st.id);
      if (stMarks.length === 0) return;

      const totalObtained = stMarks.reduce((acc, curr) => acc + curr.total_obtained, 0);
      const stSubjects = this.subjects.filter((sb) => sb.class_level === 'All' || sb.class_level === st.class);
      const totalMax = stSubjects.reduce((acc, curr) => acc + curr.max_marks, 0);
      const stPct = totalMax > 0 ? (totalObtained / totalMax) * 100 : 0;
      sumPercentages += stPct;

      const hasFailedSubject = stMarks.some((m) => m.pass_status === 'Fail');
      if (!hasFailedSubject) {
        totalStudentPass++;
      }
    });

    const passPercentage = totalStudents > 0 ? Math.round((totalStudentPass / totalStudents) * 100) : 0;
    const averagePercentage = totalStudents > 0 ? Math.round((sumPercentages / totalStudents) * 10) / 10 : 0;

    // Class-wise pass rates
    const classMap = new Map<string, { total: number; pass: number }>();
    this.students.forEach((s) => {
      const key = `${s.class} (${s.section})`;
      const current = classMap.get(key) || { total: 0, pass: 0 };
      current.total++;

      const stMarks = this.marks.filter((m) => m.student_id === s.id);
      const failed = stMarks.some((m) => m.pass_status === 'Fail');
      if (stMarks.length > 0 && !failed) {
        current.pass++;
      }
      classMap.set(key, current);
    });

    const classWisePassRate = Array.from(classMap.entries()).map(([class_name, val]) => ({
      class_name,
      total: val.total,
      pass: val.pass,
      pass_pct: val.total > 0 ? Math.round((val.pass / val.total) * 100) : 0,
    }));

    // Grade Distribution
    const gradeCounts: Record<string, number> = { 'A+': 0, A: 0, 'B+': 0, B: 0, C: 0, D: 0, F: 0 };
    this.marks.forEach((m) => {
      if (m.grade in gradeCounts) {
        gradeCounts[m.grade]++;
      }
    });

    const gradeDistribution = Object.entries(gradeCounts).map(([grade, count]) => ({
      grade,
      count,
    }));

    // Subject averages
    const subjectAverages = this.subjects.map((sub) => {
      const subMarks = this.marks.filter((m) => m.subject_id === sub.id);
      const totalScore = subMarks.reduce((acc, m) => acc + m.total_obtained, 0);
      const avg_score = subMarks.length > 0 ? Math.round((totalScore / subMarks.length) * 10) / 10 : 0;
      return {
        subject_name: sub.subject_name.split(' ')[0], // short name
        avg_score,
      };
    });

    // Recent Marks Entries
    const recentMarksEntries = this.marks.slice(-5).map((m) => {
      const student = this.getStudentById(m.student_id);
      const subject = this.getSubjectById(m.subject_id);
      return {
        student_name: student?.name || 'Unknown Student',
        student_id: student?.student_id || m.student_id,
        class_section: student ? `${student.class}-${student.section}` : '-',
        subject_name: subject?.subject_name || 'Subject',
        marks_obtained: m.total_obtained,
        grade: m.grade,
        date: 'Today',
      };
    });

    return {
      totalStudents,
      totalClasses,
      totalSubjects,
      passPercentage,
      averagePercentage,
      classWisePassRate,
      gradeDistribution,
      subjectAverages,
      recentMarksEntries,
    };
  }
}

export const store = new AcademicDataStore();
