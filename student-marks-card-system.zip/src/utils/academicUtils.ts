import { MarkEntry, Subject, CalculatedSubjectResult, StudentReportCard, Student } from '../types';

/**
 * Calculates Grade and Grade Point based on percentage
 */
export function calculateGrade(percentage: number): { grade: string; gradePoint: number; remarks: string } {
  const pct = Math.round(percentage * 10) / 10;
  if (pct >= 90) return { grade: 'A+', gradePoint: 10.0, remarks: 'Outstanding' };
  if (pct >= 80) return { grade: 'A', gradePoint: 9.0, remarks: 'Excellent' };
  if (pct >= 70) return { grade: 'B+', gradePoint: 8.0, remarks: 'Very Good' };
  if (pct >= 60) return { grade: 'B', gradePoint: 7.0, remarks: 'Good' };
  if (pct >= 50) return { grade: 'C', gradePoint: 6.0, remarks: 'Satisfactory' };
  if (pct >= 40) return { grade: 'D', gradePoint: 5.0, remarks: 'Pass' };
  return { grade: 'F', gradePoint: 0.0, remarks: 'Needs Improvement' };
}

/**
 * Validates entered marks against subject maximum constraints
 */
export function validateMarksInput(
  subject: Subject,
  internal: number,
  external: number,
  practical: number
): { isValid: boolean; error?: string } {
  if (internal < 0 || external < 0 || practical < 0) {
    return { isValid: false, error: 'Marks cannot be negative' };
  }

  const maxInt = subject.max_internal ?? 20;
  const maxExt = subject.max_external ?? 60;
  const maxPrac = subject.has_practical ? (subject.max_practical ?? 20) : 0;

  if (internal > maxInt) {
    return { isValid: false, error: `Internal marks exceed maximum (${maxInt})` };
  }
  if (external > maxExt) {
    return { isValid: false, error: `External marks exceed maximum (${maxExt})` };
  }
  if (subject.has_practical && practical > maxPrac) {
    return { isValid: false, error: `Practical marks exceed maximum (${maxPrac})` };
  }

  const total = internal + external + (subject.has_practical ? practical : 0);
  if (total > subject.max_marks) {
    return { isValid: false, error: `Total marks (${total}) exceed subject maximum (${subject.max_marks})` };
  }

  return { isValid: true };
}

/**
 * Formats mark entry calculations for a subject
 */
export function calculateSubjectResult(subject: Subject, mark?: MarkEntry): CalculatedSubjectResult {
  const internal = mark?.internal_marks ?? 0;
  const external = mark?.external_marks ?? 0;
  const practical = subject.has_practical ? (mark?.practical_marks ?? 0) : 0;
  const totalObtained = internal + external + practical;
  const maxMarks = subject.max_marks || 100;
  const percentage = maxMarks > 0 ? (totalObtained / maxMarks) * 100 : 0;
  
  const { grade, gradePoint, remarks } = calculateGrade(percentage);
  const passStatus = totalObtained >= subject.pass_marks ? 'Pass' : 'Fail';

  return {
    subject,
    mark,
    internal,
    external,
    practical,
    totalObtained,
    maxMarks,
    percentage: Math.round(percentage * 100) / 100,
    grade,
    gradePoint,
    passStatus,
    remarks: mark?.remarks || remarks,
  };
}

/**
 * Generates comprehensive Report Card for a Student
 */
export function generateStudentReportCard(
  student: Student,
  subjects: Subject[],
  marksList: MarkEntry[],
  allClassStudents: Student[],
  allMarksList: MarkEntry[]
): StudentReportCard {
  // Filter subjects for student's class level or general
  const studentSubjects = subjects.filter(
    (s) => s.class_level === 'All' || s.class_level === student.class
  );

  const subjectResults = studentSubjects.map((subject) => {
    const mark = marksList.find(
      (m) => m.student_id === student.id && m.subject_id === subject.id
    );
    return calculateSubjectResult(subject, mark);
  });

  const totalMaxMarks = subjectResults.reduce((acc, curr) => acc + curr.maxMarks, 0);
  const totalObtainedMarks = subjectResults.reduce((acc, curr) => acc + curr.totalObtained, 0);
  const overallPercentage = totalMaxMarks > 0 ? (totalObtainedMarks / totalMaxMarks) * 100 : 0;

  const failedCount = subjectResults.filter((r) => r.passStatus === 'Fail').length;
  let resultStatus: 'PASS' | 'FAIL' | 'COMPARTMENT' = 'PASS';
  if (failedCount > 2) {
    resultStatus = 'FAIL';
  } else if (failedCount > 0) {
    resultStatus = 'COMPARTMENT';
  }

  const { grade: overallGrade } = calculateGrade(overallPercentage);
  const overallGPA =
    subjectResults.length > 0
      ? Math.round(
          (subjectResults.reduce((acc, curr) => acc + curr.gradePoint, 0) /
            subjectResults.length) *
            100
        ) / 100
      : 0;

  // Compute Rank in Class & Section
  const sameClassStudents = allClassStudents.filter(
    (s) => s.class === student.class && s.section === student.section
  );

  const studentScores = sameClassStudents.map((st) => {
    const stMarks = allMarksList.filter((m) => m.student_id === st.id);
    const score = stMarks.reduce((acc, m) => acc + m.total_obtained, 0);
    return { studentId: st.id, score };
  });

  studentScores.sort((a, b) => b.score - a.score);
  const rankIndex = studentScores.findIndex((item) => item.studentId === student.id);
  const classRank = rankIndex >= 0 ? rankIndex + 1 : 1;

  // Average attendance
  const attendances = marksList
    .filter((m) => m.student_id === student.id && m.attendance_pct !== undefined)
    .map((m) => m.attendance_pct!);
  const overallAttendancePct =
    attendances.length > 0
      ? Math.round(attendances.reduce((a, b) => a + b, 0) / attendances.length)
      : 92;

  return {
    student,
    academic_year: student.academic_year || '2025-2026',
    subjectResults,
    totalMaxMarks,
    totalObtainedMarks,
    overallPercentage: Math.round(overallPercentage * 100) / 100,
    overallGrade,
    overallGPA,
    result: resultStatus,
    classRank,
    totalStudentsInClass: sameClassStudents.length || 1,
    overallAttendancePct,
    issueDate: new Date().toISOString().split('T')[0],
  };
}
