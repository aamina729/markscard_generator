import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Student, Subject, MarkEntry, SchoolSettings, DashboardStats } from '../types';

export interface ToastMessage {
  id: string;
  type: 'success' | 'error' | 'info' | 'warning';
  title: string;
  message?: string;
}

interface AppContextType {
  students: Student[];
  subjects: Subject[];
  marks: MarkEntry[];
  settings: SchoolSettings | null;
  stats: DashboardStats | null;
  loading: boolean;
  toasts: ToastMessage[];
  showToast: (title: string, message?: string, type?: ToastMessage['type']) => void;
  removeToast: (id: string) => void;
  refetchAll: () => Promise<void>;
  addStudent: (data: Omit<Student, 'id'>) => Promise<boolean>;
  updateStudent: (id: string, data: Partial<Student>) => Promise<boolean>;
  deleteStudent: (id: string) => Promise<boolean>;
  addSubject: (data: Omit<Subject, 'id'>) => Promise<boolean>;
  updateSubject: (id: string, data: Partial<Subject>) => Promise<boolean>;
  deleteSubject: (id: string) => Promise<boolean>;
  saveBatchMarks: (
    entries: Array<{
      student_id: string;
      subject_id: string;
      internal_marks: number;
      external_marks: number;
      practical_marks: number;
      remarks?: string;
      attendance_pct?: number;
    }>
  ) => Promise<boolean>;
  updateSettings: (data: Partial<SchoolSettings>) => Promise<boolean>;
  resetDatabase: () => Promise<boolean>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [students, setStudents] = useState<Student[]>([]);
  const [subjects, setSubjects] = useState<Subject[]>([]);
  const [marks, setMarks] = useState<MarkEntry[]>([]);
  const [settings, setSettings] = useState<SchoolSettings | null>(null);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const showToast = useCallback((title: string, message?: string, type: ToastMessage['type'] = 'success') => {
    const id = `toast-${Date.now()}-${Math.random()}`;
    setToasts((prev) => [...prev, { id, title, message, type }]);
    setTimeout(() => {
      removeToast(id);
    }, 4000);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const refetchAll = useCallback(async () => {
    try {
      setLoading(true);
      const [stRes, subRes, mkRes, setRes, statRes] = await Promise.all([
        fetch('/api/students'),
        fetch('/api/subjects'),
        fetch('/api/marks'),
        fetch('/api/settings'),
        fetch('/api/dashboard/stats'),
      ]);

      const stData = await stRes.json();
      const subData = await subRes.json();
      const mkData = await mkRes.json();
      const setData = await setRes.json();
      const statData = await statRes.json();

      setStudents(stData);
      setSubjects(subData);
      setMarks(mkData);
      setSettings(setData);
      setStats(statData);
    } catch (err) {
      console.error('Error fetching system data:', err);
      showToast('Error', 'Failed to load system data from server', 'error');
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    refetchAll();
  }, [refetchAll]);

  const addStudent = async (data: Omit<Student, 'id'>) => {
    try {
      const res = await fetch('/api/students', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        showToast('Student Added', `${data.name} registered successfully`);
        await refetchAll();
        return true;
      }
      throw new Error('Failed to create student');
    } catch (err: any) {
      showToast('Error', err.message || 'Failed to add student', 'error');
      return false;
    }
  };

  const updateStudent = async (id: string, data: Partial<Student>) => {
    try {
      const res = await fetch(`/api/students/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        showToast('Student Updated', 'Student record updated successfully');
        await refetchAll();
        return true;
      }
      throw new Error('Failed to update student');
    } catch (err: any) {
      showToast('Error', err.message || 'Failed to update student', 'error');
      return false;
    }
  };

  const deleteStudent = async (id: string) => {
    try {
      const res = await fetch(`/api/students/${id}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('Student Deleted', 'Student record removed from system');
        await refetchAll();
        return true;
      }
      throw new Error('Failed to delete student');
    } catch (err: any) {
      showToast('Error', err.message || 'Failed to delete student', 'error');
      return false;
    }
  };

  const addSubject = async (data: Omit<Subject, 'id'>) => {
    try {
      const res = await fetch('/api/subjects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        showToast('Subject Added', `${data.subject_name} added successfully`);
        await refetchAll();
        return true;
      }
      throw new Error('Failed to add subject');
    } catch (err: any) {
      showToast('Error', err.message || 'Failed to add subject', 'error');
      return false;
    }
  };

  const updateSubject = async (id: string, data: Partial<Subject>) => {
    try {
      const res = await fetch(`/api/subjects/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        showToast('Subject Updated', 'Subject configured successfully');
        await refetchAll();
        return true;
      }
      throw new Error('Failed to update subject');
    } catch (err: any) {
      showToast('Error', err.message || 'Failed to update subject', 'error');
      return false;
    }
  };

  const deleteSubject = async (id: string) => {
    try {
      const res = await fetch(`/api/subjects/${id}`, { method: 'DELETE' });
      if (res.ok) {
        showToast('Subject Removed', 'Subject removed from curriculum');
        await refetchAll();
        return true;
      }
      throw new Error('Failed to delete subject');
    } catch (err: any) {
      showToast('Error', err.message || 'Failed to delete subject', 'error');
      return false;
    }
  };

  const saveBatchMarks = async (entries: Array<{
    student_id: string;
    subject_id: string;
    internal_marks: number;
    external_marks: number;
    practical_marks: number;
    remarks?: string;
    attendance_pct?: number;
  }>) => {
    try {
      const res = await fetch('/api/marks/batch', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ entries }),
      });
      if (res.ok) {
        showToast('Marks Saved', `${entries.length} mark record(s) saved and grades re-calculated!`);
        await refetchAll();
        return true;
      }
      throw new Error('Failed to save marks batch');
    } catch (err: any) {
      showToast('Error', err.message || 'Failed to save marks', 'error');
      return false;
    }
  };

  const updateSettings = async (data: Partial<SchoolSettings>) => {
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });
      if (res.ok) {
        showToast('Settings Updated', 'School profile and card configuration saved');
        await refetchAll();
        return true;
      }
      throw new Error('Failed to save settings');
    } catch (err: any) {
      showToast('Error', err.message || 'Failed to save settings', 'error');
      return false;
    }
  };

  const resetDatabase = async () => {
    try {
      const res = await fetch('/api/seed', { method: 'POST' });
      if (res.ok) {
        showToast('Database Reset', 'Sample academic records restored');
        await refetchAll();
        return true;
      }
      throw new Error('Reset failed');
    } catch (err: any) {
      showToast('Error', err.message || 'Failed to reset database', 'error');
      return false;
    }
  };

  return (
    <AppContext.Provider
      value={{
        students,
        subjects,
        marks,
        settings,
        stats,
        loading,
        toasts,
        showToast,
        removeToast,
        refetchAll,
        addStudent,
        updateStudent,
        deleteStudent,
        addSubject,
        updateSubject,
        deleteSubject,
        saveBatchMarks,
        updateSettings,
        resetDatabase,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
