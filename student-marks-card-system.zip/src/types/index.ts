export type Gender = 'Male' | 'Female' | 'Other';

export interface Student {
  id: string;
  student_id: string; // e.g. STU-2026-001
  roll_number: string; // e.g. 101
  name: string;
  gender: Gender;
  dob: string; // YYYY-MM-DD
  class: string; // e.g. "Class 10"
  section: string; // e.g. "A"
  academic_year: string; // e.g. "2025-2026"
  parent_name: string;
  phone: string;
  email?: string;
  address: string;
  photo?: string;
}

export interface Subject {
  id: string;
  subject_code: string; // e.g. MAT101
  subject_name: string; // e.g. Mathematics
  max_marks: number; // e.g. 100
  pass_marks: number; // e.g. 35 or 40
  max_internal?: number; // e.g. 20
  max_external?: number; // e.g. 60
  max_practical?: number; // e.g. 20
  has_practical: boolean;
  class_level: string; // e.g. "Class 10" or "All"
}

export interface MarkEntry {
  id: string;
  student_id: string;
  subject_id: string;
  internal_marks: number;
  external_marks: number;
  practical_marks: number;
  total_obtained: number;
  percentage: number;
  grade: string; // A+, A, B+, B, C, D, F
  grade_point: number;
  pass_status: 'Pass' | 'Fail';
  remarks: string;
  attendance_pct?: number;
}

export interface CalculatedSubjectResult {
  subject: Subject;
  mark?: MarkEntry;
  internal: number;
  external: number;
  practical: number;
  totalObtained: number;
  maxMarks: number;
  percentage: number;
  grade: string;
  gradePoint: number;
  passStatus: 'Pass' | 'Fail';
  remarks: string;
}

export interface StudentReportCard {
  student: Student;
  academic_year: string;
  subjectResults: CalculatedSubjectResult[];
  totalMaxMarks: number;
  totalObtainedMarks: number;
  overallPercentage: number;
  overallGrade: string;
  overallGPA: number;
  result: 'PASS' | 'FAIL' | 'COMPARTMENT';
  classRank: number;
  totalStudentsInClass: number;
  overallAttendancePct: number;
  issueDate: string;
}

export interface SchoolSettings {
  school_name: string;
  school_code: string;
  affiliation_no: string;
  address: string;
  city_state_zip: string;
  phone: string;
  email: string;
  website: string;
  logo_url: string;
  seal_url: string;
  principal_name: string;
  principal_title: string;
  class_teacher_name: string;
  academic_year_current: string;
  card_theme: 'classic' | 'modern' | 'academic';
}

export interface User {
  id: string;
  username: string;
  name: string;
  role: 'Admin' | 'Teacher' | 'Principal';
  email: string;
  avatar: string;
}

export interface DashboardStats {
  totalStudents: number;
  totalClasses: number;
  totalSubjects: number;
  passPercentage: number;
  averagePercentage: number;
  classWisePassRate: { class_name: string; total: number; pass: number; pass_pct: number }[];
  gradeDistribution: { grade: string; count: number }[];
  subjectAverages: { subject_name: string; avg_score: number }[];
  recentMarksEntries: {
    student_name: string;
    student_id: string;
    class_section: string;
    subject_name: string;
    marks_obtained: number;
    grade: string;
    date: string;
  }[];
}
