import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createServer as createViteServer } from 'vite';
import { store } from './src/backend/store';
import { generateStudentReportCard } from './src/utils/academicUtils';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // ----------------------------------------------------
  // AUTH ROUTES
  // ----------------------------------------------------
  app.post('/api/auth/login', (req, res) => {
    const { username, password, role } = req.body;
    // Simple password validation for demo: "admin123" or any
    if (!username) {
      return res.status(400).json({ error: 'Username is required' });
    }
    const user = store.login(username, role);
    return res.json({ success: true, user });
  });

  app.get('/api/auth/me', (req, res) => {
    const user = store.getCurrentUser();
    return res.json({ user });
  });

  app.post('/api/auth/logout', (req, res) => {
    store.logout();
    return res.json({ success: true });
  });

  // ----------------------------------------------------
  // DASHBOARD STATS
  // ----------------------------------------------------
  app.get('/api/dashboard/stats', (req, res) => {
    const stats = store.getDashboardStats();
    return res.json(stats);
  });

  // ----------------------------------------------------
  // SETTINGS
  // ----------------------------------------------------
  app.get('/api/settings', (req, res) => {
    return res.json(store.getSettings());
  });

  app.put('/api/settings', (req, res) => {
    const updated = store.updateSettings(req.body);
    return res.json(updated);
  });

  // ----------------------------------------------------
  // STUDENTS CRUD
  // ----------------------------------------------------
  app.get('/api/students', (req, res) => {
    let students = store.getStudents();
    const { search, class: classFilter, section: sectionFilter, year } = req.query;

    if (search && typeof search === 'string') {
      const q = search.toLowerCase();
      students = students.filter(
        (s) =>
          s.name.toLowerCase().includes(q) ||
          s.student_id.toLowerCase().includes(q) ||
          s.roll_number.toLowerCase().includes(q) ||
          s.class.toLowerCase().includes(q)
      );
    }

    if (classFilter && typeof classFilter === 'string' && classFilter !== 'All') {
      students = students.filter((s) => s.class === classFilter);
    }

    if (sectionFilter && typeof sectionFilter === 'string' && sectionFilter !== 'All') {
      students = students.filter((s) => s.section === sectionFilter);
    }

    if (year && typeof year === 'string' && year !== 'All') {
      students = students.filter((s) => s.academic_year === year);
    }

    return res.json(students);
  });

  app.get('/api/students/:id', (req, res) => {
    const student = store.getStudentById(req.params.id);
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }
    const marks = store.getStudentMarks(student.id);
    return res.json({ student, marks });
  });

  app.post('/api/students', (req, res) => {
    const newStudent = store.addStudent(req.body);
    return res.status(201).json(newStudent);
  });

  app.put('/api/students/:id', (req, res) => {
    const updated = store.updateStudent(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'Student not found' });
    }
    return res.json(updated);
  });

  app.delete('/api/students/:id', (req, res) => {
    const success = store.deleteStudent(req.params.id);
    if (!success) {
      return res.status(404).json({ error: 'Student not found' });
    }
    return res.json({ success: true });
  });

  // ----------------------------------------------------
  // SUBJECTS CRUD
  // ----------------------------------------------------
  app.get('/api/subjects', (req, res) => {
    return res.json(store.getSubjects());
  });

  app.post('/api/subjects', (req, res) => {
    const newSubj = store.addSubject(req.body);
    return res.status(201).json(newSubj);
  });

  app.put('/api/subjects/:id', (req, res) => {
    const updated = store.updateSubject(req.params.id, req.body);
    if (!updated) {
      return res.status(404).json({ error: 'Subject not found' });
    }
    return res.json(updated);
  });

  app.delete('/api/subjects/:id', (req, res) => {
    const success = store.deleteSubject(req.params.id);
    if (!success) {
      return res.status(404).json({ error: 'Subject not found' });
    }
    return res.json({ success: true });
  });

  // ----------------------------------------------------
  // MARKS ENTRY & COMPUTATION
  // ----------------------------------------------------
  app.get('/api/marks', (req, res) => {
    return res.json(store.getMarks());
  });

  app.get('/api/marks/student/:studentId', (req, res) => {
    return res.json(store.getStudentMarks(req.params.studentId));
  });

  app.post('/api/marks/batch', (req, res) => {
    const { entries } = req.body;
    if (!Array.isArray(entries)) {
      return res.status(400).json({ error: 'Entries array is required' });
    }
    const saved = store.saveBatchMarks(entries);
    return res.json({ success: true, count: saved.length, saved });
  });

  // ----------------------------------------------------
  // MARKS CARD PREVIEW / GENERATION REPORT DATA
  // ----------------------------------------------------
  app.get('/api/markscard/:studentId', (req, res) => {
    const student = store.getStudentById(req.params.studentId);
    if (!student) {
      return res.status(404).json({ error: 'Student not found' });
    }

    const subjects = store.getSubjects();
    const marksList = store.getMarks();
    const allStudents = store.getStudents();

    const reportCard = generateStudentReportCard(
      student,
      subjects,
      marksList,
      allStudents,
      marksList
    );

    return res.json(reportCard);
  });

  // Seed / Reset Data
  app.post('/api/seed', (req, res) => {
    store.seed();
    return res.json({ success: true, message: 'Database reset to default seed data' });
  });

  // ----------------------------------------------------
  // VITE / STATIC SERVING
  // ----------------------------------------------------
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Academic Marks Card System running at http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
